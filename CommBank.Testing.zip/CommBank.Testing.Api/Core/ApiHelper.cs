﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using CsvHelper;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using TechTalk.SpecFlow;
using DataTable = System.Data.DataTable;
using CommBank.Testing.Allure;
using Allure.Commons;
using CommBank.Testing.Cryptography;
using System.Configuration;


#pragma warning disable 618

namespace CommBank.Testing.Api.Core
{

    public class ApiHelper

    {
        private static readonly HttpClient Client = new HttpClient();

        readonly Crypto _crypto = new Crypto();

        Dictionary<string, object> _objDictionary;

        readonly JavaScriptSerializer _serializer = new JavaScriptSerializer();

        List<KeyValuePair<string, string>> _jsonResponseList = new List<KeyValuePair<string, string>>();

        readonly List<KeyValuePair<string, string>> _actualRespList = new List<KeyValuePair<string, string>>();

        readonly List<KeyValuePair<string, string>> _expectedRespList = new List<KeyValuePair<string, string>>();

        readonly string _parentKey = null;

        readonly int _listCount = 0;

        readonly int _dictCount = 0;


        //Convert Csv to DataTable
        public DataTable CsvToDataTable(string csvFilePath)
        {
            try
            {
                var reader = File.OpenText(csvFilePath);
                var csv = new CsvReader(reader);
                var dt = new DataTable();
                csv.Read();
                csv.ReadHeader();
                foreach (var header in csv.Context.HeaderRecord)
                {
                    dt.Columns.Add(header);
                }

                while (csv.Read())
                {
                    var row = dt.NewRow();
                    foreach (DataColumn column in dt.Columns)
                    {
                        row[column.ColumnName] = csv.GetField(column.DataType, column.ColumnName);
                    }
                    dt.Rows.Add(row);
                }
                return dt;
            }
            catch (Exception e)
            {
                AllureHelper.ReportEvent("Error in converting CSV datafile to DataTable" + e.Message, "", Status.failed);
                Assert.Fail("Error in converting CSV datafile to DataTable" + Environment.NewLine + e.Message);
                return null;
            }
        }



        public string ConstructJsonRequest(string dataRow, DataTable dt)
        {
            var rows = dt.Select("TestCase" + " LIKE '" + dataRow + "'");

            if (rows.Length < 1)
            {
                AllureHelper.ReportEvent("Unable to find the data set with the test case name:" + dataRow, "", Status.failed);
                Assert.Fail("Unable to find the data set with the test case name:" + dataRow);
            }

            Dictionary<string,object> request = new Dictionary<string, object>();

            for (int c = 0; c < dt.Columns.Count; c++)
            {
                DataColumn column = dt.Columns[c];
                if (column.ToString().ToLower().Contains("testcase") || column.ToString().StartsWith("Res."))
                {
                    continue;
                }
                string parentKey;
                if (column.ToString().Contains("{}"))
                {
                    parentKey = column.ToString().RemoveSpecialCharacters();
                    var childRequest = ConstructChildRequest(dt, rows, column.Ordinal, parentKey, out var newColIndex);
                    request.Add(parentKey, childRequest);
                    c = newColIndex-1;
                }
                else if (column.ToString().Contains("[]"))
                {
                    var arrayList = GetItemsAsList(rows, column.Ordinal);
                    request.Add(column.ToString().RemoveSpecialCharacters(), arrayList);
                }
                else
                {
                    request.Add(column.ToString().RemoveSpecialCharacters(), rows[0][column.ToString()].ToString());
                }
            }
            return JsonConvert.SerializeObject(request, Formatting.Indented);
        }



        public Dictionary<string, object> ConstructChildRequest(DataTable dt, DataRow[] rows, int colIndex, string parentKey, out int currentColIndex)
        {
            Dictionary<string, object> request = new Dictionary<string, object>();
            currentColIndex = colIndex;
            for (int c = colIndex + 1; c < dt.Columns.Count; c++)
            {
                DataColumn column = dt.Columns[c];

                if(column.ToString().StartsWith("Res."))
                {
                    continue;
                }

                if (column.ToString().Contains("."))
                {
                    var arrColumns = column.ToString().Split('.').ToArray();
                    if (arrColumns[arrColumns.Length - 2] == parentKey)
                    {
                        if (column.ToString().Contains("{}[]"))
                        {
                            string newParentKey = arrColumns[arrColumns.Length - 1].RemoveSpecialCharacters();
                            var arrRequest = ConstructArrayRequest(dt, rows, column.Ordinal, newParentKey, out int newColIndex).ToArray();
                            request.Add(newParentKey, arrRequest);
                            c = newColIndex;
                        }
                        else if (column.ToString().Contains("{}"))
                        {
                            string newParentKey = arrColumns[arrColumns.Length - 1].RemoveSpecialCharacters();
                            var childRequest = ConstructChildRequest(dt, rows, column.Ordinal, newParentKey, out int newColIndex);
                            request.Add(newParentKey, childRequest);
                            c = newColIndex;
                        }
                        else if (column.ToString().Contains("[]"))
                        {
                            string newParentKey = arrColumns[arrColumns.Length - 1].RemoveSpecialCharacters();
                            var arrayList = GetItemsAsList(rows, column.Ordinal);
                            request.Add(newParentKey, arrayList);
                        }
                        else
                        {
                            request.Add(arrColumns[arrColumns.Length - 1], rows[0][column.ToString()].ToString());
                        }
                    }
                    else
                    {
                        AllureHelper.ReportEvent("Parent Key is not as expected as per the rule. Please check", "", Status.failed);
                        Assert.Fail("Parent Key is not as expected as per the rule. Please check");
                    }
                }
                else
                {
                    currentColIndex = c;
                    return request;
                }
                currentColIndex = c;
            }

            currentColIndex = currentColIndex + 1;
            return request;
        }

        public List<Dictionary<string, object>> ConstructArrayRequest(DataTable dt, DataRow[] rows, int colIndex, string parentKey, out int currentColIndex)
        {
            var requestList = new List<Dictionary<string, object>>();
            currentColIndex = colIndex;
            foreach (var dataRow in rows)
            {
                Dictionary<string, object> arrRequest = new Dictionary<string, object>();
                for (int c = colIndex + 1; c < dt.Columns.Count; c++)
                {
                    DataColumn column = dt.Columns[c];

                    if (!column.ToString().Contains("."))
                    {
                        break;
                    }
                    var arrColumns = column.ToString().Split('.').ToArray();
                    currentColIndex = c;
                    if (arrColumns[arrColumns.Length - 2] != parentKey)
                    {
                        currentColIndex = currentColIndex - 1;
                        break;
                    }
                    arrRequest.Add(arrColumns[arrColumns.Length - 1], dataRow[column.ToString()].ToString());
                }
                requestList.Add(arrRequest);
            }

            return requestList;
        }




        public List<string> GetItemsAsList(DataRow[] rows, int colIndex)
        {
            List<string> itemList = new List<string>();
            foreach (DataRow dataRow in rows)
            {
                if (dataRow[colIndex].ToString().Trim().Length > 1)
                {
                    if (dataRow[colIndex].ToString().Contains(","))
                    {
                        var tempList = dataRow[colIndex].ToString().Split(',').ToList();
                        itemList.AddRange(tempList);
                    }
                    else
                    {
                        itemList.Add(dataRow[colIndex].ToString());
                    }
                }
            }

            return itemList;
        }



        public string FromFileAsString(string filePath) => File.ReadAllText(filePath, Encoding.UTF8);


        //Post API
        public async Task Post(string req, string url)
        {
            await InvokePostApi(req, url).ConfigureAwait(false);
        }


        //Invoke PUT API
        public async Task InvokePutApi(string req, string finalUrl)
        {
            var json = JObject.Parse(req);
            Client.DefaultRequestHeaders.Accept.Clear();

            var authInfo = @"qco" + ":" + "rules";
            authInfo = Convert.ToBase64String(Encoding.Default.GetBytes(authInfo));
            Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authInfo);

            Client.DefaultRequestHeaders.Add("If-Match", ScenarioContext.Current["eTag"].ToString());
            

            var payLoad = new StringContent(json.ToString(), Encoding.UTF8, "application/json");


            var response = await Client.PutAsync(finalUrl, payLoad).ConfigureAwait(false);
            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            //Console.WriteLine(response.Content.Headers.ContentType.MediaType);

            if (ScenarioContext.Current != null)
            {
                ScenarioContext.Current["ResponseHeader"] = response.Headers;
                ScenarioContext.Current["MediaType"] = response.Content.Headers.ContentType.MediaType;
                ScenarioContext.Current["ResponseCode"] = (int)response.StatusCode;
                ScenarioContext.Current["ResponseContent"] = content;
            }
            _jsonResponseList.Clear();
        }



        //Invoke GET API
        public async Task<string> InvokeGetApi(string finalUrl)
        {
            _actualRespList.Clear();
            Client.DefaultRequestHeaders.Accept.Clear();            
            Client.DefaultRequestHeaders.Add("userid", @"AU\alimu");
            Client.DefaultRequestHeaders.Add("useridtype", "LAN ID");
            Client.DefaultRequestHeaders.Add("correlationid", "123-123-123");
            Client.DefaultRequestHeaders.Add("cba-api-key", "74656d63-fb18-1fa3-e053-1d1bf40a8b8f");
            Client.DefaultRequestHeaders.Add("event-timestamp", "2015-09-05T13:15:30Z");
            Client.DefaultRequestHeaders.Add("source-system", "sap");
            Client.DefaultRequestHeaders.Add("Authorization", "Basic QVVUMDFcQUNPRV9GQ09fQVBJX1Q6TEJqNTlIdDdiNDZWaVpNZA==");
            Client.DefaultRequestHeaders.Add("host", "int-kafkaapi-v1-uat.service.syd1.sd.nprod.cba");

            string authInfo = @"AUT01\ACOE_FCO_API_D" + ":" + "f24znph6Vu12DWKU";
            authInfo = Convert.ToBase64String(Encoding.Default.GetBytes(authInfo));
            Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authInfo);

            var response = await Client.GetAsync(finalUrl).ConfigureAwait(false);

            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (ScenarioContext.Current != null)
            {
                ScenarioContext.Current["ResponseHeader"] = response.Headers;
                ScenarioContext.Current["MediaType"] = response.Content.Headers.ContentType.MediaType;
                ScenarioContext.Current["ResponseCode"] = (int)response.StatusCode;
                ScenarioContext.Current["ResponseContent"] = content;

                if (response.Content.Headers.ContentType.MediaType == "application/json")
                {
                    _objDictionary = _serializer.Deserialize<Dictionary<string, object>>(content);

                    ScenarioContext.Current["ResponseObject"] = _objDictionary;

                    _jsonResponseList = DictionaryToList(ref _objDictionary, _parentKey, _listCount, _dictCount);

                    _actualRespList.AddRange(_jsonResponseList);

                    ScenarioContext.Current["ActualRespList"] = _actualRespList;
                }
                
            }

            _jsonResponseList.Clear();
            return content;

        }


        
        //Invoke POST API
        private async Task InvokePostApi(string req, string finalUrl)
        {
        ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, errors) => true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls |
                                                   SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            _actualRespList.Clear();
            var json = JObject.Parse(req);
            Client.DefaultRequestHeaders.Accept.Clear();            
            Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
            System.Text.ASCIIEncoding.ASCII.GetBytes(
               $"{ConfigurationManager.AppSettings["GOT.CaseCreator"]}:{_crypto.Decrypt(ConfigurationManager.AppSettings["GOT.Password"])}")));
            var payLoad = new StringContent(json.ToString(), Encoding.UTF8, "application/json");
            var response = await Client.PostAsync(finalUrl, payLoad).ConfigureAwait(false);
            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (ScenarioContext.Current != null)
            {
                ScenarioContext.Current["ResponseHeader"] = response.Headers;
                ScenarioContext.Current["MediaType"] = response.Content.Headers.ContentType.MediaType;
                ScenarioContext.Current["ResponseCode"] = (int)response.StatusCode;
                ScenarioContext.Current["HTTPResponseCode"] = response.EnsureSuccessStatusCode().StatusCode.ToString();                
                ScenarioContext.Current["ResponseContent"] = content;

                if (response.Content.Headers.ContentType.MediaType == "application/json")
                {
                    _objDictionary = _serializer.Deserialize<Dictionary<string, object>>(content);

                    ScenarioContext.Current["ResponseObject"] = _objDictionary;

                    _jsonResponseList = DictionaryToList(ref _objDictionary, _parentKey, _listCount, _dictCount);

                    _actualRespList.AddRange(_jsonResponseList);

                    ScenarioContext.Current["ActualRespList"] = _actualRespList;
                }
            }

            _jsonResponseList.Clear();
        }


        

        public void ConstructExpectedResponseListFromDict(Dictionary<string, object> tempDict)
        {
            _jsonResponseList = DictionaryToList(ref tempDict, _parentKey, _listCount, _dictCount);
            _expectedRespList.AddRange(_jsonResponseList);
            ScenarioContext.Current["ExpectedRespList"] = _expectedRespList;
            
            //foreach (var item in expectedRespList)
            //{
            //    Console.WriteLine($"{item.Key},{item.Value}");
            //}

            _jsonResponseList.Clear();
        }



        public void ConstructExpectedResponseListFromTable(DataTable dtable, string testCaseName)
        {
            //var rows = dtable.Select("TestCaseName" + " LIKE '%" + testCaseName + "%'");
            var rows = dtable.Select("TestCase" + " LIKE '" + testCaseName + "'");

            if (rows.Length < 1)
            {
                AllureHelper.ReportEvent("Unable to find the data set with the test case name:" + testCaseName, "", Status.failed);
                Assert.Fail("Unable to find the data set with the test case name:" + testCaseName);
            }

            foreach (DataRow row in rows)
            {
                foreach (DataColumn column in dtable.Columns)
                {
                    if(column.ColumnName.StartsWith("Res."))
                    {
                        var newColName = column.ColumnName.Substring(4);
                        var value = row[column] as string;
                        if (!String.IsNullOrEmpty(value))
                        {
                            _expectedRespList.Add(new KeyValuePair<string, string>(newColName, value));
                        }
                    }
                                       
                }
            }
            if(_expectedRespList.Count < 1)
            {
                AllureHelper.ReportEvent("One or more column names in the expected response is not in proper format. The Column Name should start with 'Res.'", "", Status.failed);
                Assert.Fail("One or more column names in the expected response is not in proper format. The Column Name should start with 'Res.'");
            }
            else
            {
                foreach (var item in _expectedRespList)
                {
                    Console.WriteLine($"{item.Key},{item.Value}");
                    AllureHelper.ReportEvent("Expected KeyValuePairs: " + $"{item.Key} , {item.Value}","",Status.passed);
                }
                ScenarioContext.Current["ExpectedRespList"] = _expectedRespList;
            }

        }


        // Search the Response for the key (eg: errors[].ID) and its value
        public void SearchActualResponseList(string key,string expval, object actRespList)
        {
            bool valFound = false;
            bool keyFound = false;
            
            var actResList = actRespList as List<KeyValuePair<string, string>>;
            Regex newsearchKey;
            key = Regex.Replace(key, @"\[]", @"\[[0-9]+\]");
            newsearchKey = new Regex(key);

            if (actResList != null)
            {
                for (var j = 0; j < actResList.Count; j++)
                {
                    if (newsearchKey.IsMatch(actResList.ElementAt(j).Key))
                    {
                        keyFound = true;
                        if (actResList.ElementAt(j).Value.Contains(expval))
                        {
                            valFound = true;
                            break;
                        }
                        
                    }
                }

            }

            if (valFound)
            {
                ScenarioContext.Current["ResultType"] = "PASSED";
            }
            else
            {
                ScenarioContext.Current["ResultType"] = "ERROR";
            }

            
        }




        // Search the Response for the key at specific location (eg: errors[1].ID) and its value
        public void SearchActualResponseListForSpecificKey(string keys, object actRespList)
        {
            var keyNotFound = true;
            var actualRespList = actRespList as List<KeyValuePair<string, string>>;
 
           
            if (actualRespList != null)
            {
                foreach (var item in actualRespList)
                {
                    if (item.Key == keys)
                    {
                        keyNotFound = false;
                        ScenarioContext.Current[keys] = item.Value;
                    }
                }
            }
           

            if(keyNotFound)
            {
                AllureHelper.ReportEvent($"The Expected Key \"{keys}\" is not found in the actual response", "", Status.failed);
                Assert.Fail($"The Expected Key \"{keys}\" is not found in the actual response");
            }
                
        }




        //Retrieve the value of a key from the Response Header
        public void RetrieveValuefromResponseHeader(string headerKey)
        {
            var headerKeyFound = false;
            var responseHeader = ScenarioContext.Current["ResponseHeader"] as HttpResponseHeaders;
            if(headerKey == "eTag")
            {
                if (responseHeader.ETag.Tag != null)
                {
                    ScenarioContext.Current[headerKey] = responseHeader.ETag.Tag;
                    headerKeyFound = true;
                }
            }

            if (headerKeyFound)
            {
                ScenarioContext.Current["ResultType"] = "PASSED";
            }
            else
            {
                ScenarioContext.Current["ResultType"] = "ERROR";
            }

        }



        // Retrieve the value of a key from the response
        public void RetrieveValue(string key, object actRespList)
        {
            var actualRespList = actRespList as List<KeyValuePair<string, string>>;
            var keyFound = false;

            if (actualRespList != null)
                foreach (var item in actualRespList)
                {
                    if (item.Key == key)
                    {
                        keyFound = true;
                        ScenarioContext.Current[key] = item.Value;
                        break;
                    }
                }

            if (keyFound)
            {
                ScenarioContext.Current["ResultType"] = "PASSED";
            }
            else
            {
                ScenarioContext.Current["ResultType"] = "ERROR";

            }


        }



        //Compare ActualResponse with the Expected Response in JSON Format
        public void CompareActualVsExpectedResponseFromJson(object expRespList, object actRespList)
        {
            var expectedRespList = expRespList as List<KeyValuePair<string, string>>;
            var actualRespList = actRespList as List<KeyValuePair<string, string>>;

            List<KeyValuePair<string, string>> newKeysList = new List<KeyValuePair<string, string>>();
            if (expectedRespList != null)
            {
                string[] expectedKeys = new string[expectedRespList.Count];
                if (actualRespList != null)
                {
                    string[] actualKeys = new string[actualRespList.Count];
                    List<string> keysNotFound = new List<string>();
                    bool newKeysAvailable;
                    bool isError = false;
                    bool keyFound = false;

                    //Check for the expected KV Pairs
                    for (var i=0;i< expectedRespList.Count;i++)
                    {
                        if(expectedRespList.ElementAt(i).Key == "pzPageNameHash")
                        {
                            continue;
                        }

                        for (var j = 0; j < actualRespList.Count; j++)
                        {
                            if (expectedRespList.ElementAt(i).Key.Equals(actualRespList.ElementAt(j).Key))
                            {
                                keyFound = true;

                                //Value Mismatch for a key in the Actual Response
                                if (!(expectedRespList.ElementAt(i).Value.Equals(actualRespList.ElementAt(j).Value)))
                                {
                                    isError = true;
                                    Console.WriteLine($"Values for the key {expectedRespList.ElementAt(i).Key} does not match! Expected Value:{expectedRespList.ElementAt(i).Value}, Actual Value:{actualRespList.ElementAt(j).Value}");
                                    AllureHelper.ReportEvent($"Values for the key {expectedRespList.ElementAt(i).Key} does not match! Expected Value:{expectedRespList.ElementAt(i).Value}, Actual Value:{actualRespList.ElementAt(j).Value}", "", Status.failed);
                                }
                                break;
                            }
                            keyFound = false;
                        }

                        if(keyFound==false)
                        {
                            keysNotFound.Add(expectedRespList.ElementAt(i).Key);
                        }
                
                    }

                    //Keys Not Found in the Actual Response
                    if(keysNotFound.Count != 0)
                    {
                        isError = true;
                        Console.WriteLine("The following keys are not found in the actual response: ");
                        foreach (var key in keysNotFound)
                        {
                            Console.WriteLine($"Expected Key:{key}");
                            AllureHelper.ReportEvent($"Key Not Found in Actual Response. Expected Key:{key}", "", Status.failed);
                        }
                    }
            

                    //Check for the new Keys in Actual Response
                    for (var i=0;i< expectedRespList.Count; i++)
                    {
                        expectedKeys[i] = expectedRespList.ElementAt(i).Key;
                    }

                    for (var k = 0; k < actualRespList.Count; k++)
                    {
                        actualKeys[k] = actualRespList.ElementAt(k).Key;
                    }
            
                    var newKeys = actualKeys.Except(expectedKeys);

                    var enumerable = newKeys as string[] ?? newKeys.ToArray();
                    if (!enumerable.Any())
                    {
                        // Warn about emptiness
                        newKeysAvailable = false;
                    }
                    else
                    {
                        newKeysAvailable = true;
                        foreach (var item in enumerable)
                        {
                            //Retrieve the KVPair for the New Key
                            var newKvPair = from kvPair in actualRespList
                                where kvPair.Key == item
                                select kvPair;
                            foreach (var newitem in newKvPair)
                            {
                                newKeysList.Add(newitem);
                            }
                        }
                    }

                    if (newKeysAvailable)
                    {
                        isError = true;
                        Console.WriteLine("Additional Key Value pairs present in the Actual Response: "); 
                        foreach(var item in newKeysList)
                        {
                            Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
                            AllureHelper.ReportEvent($"Additional Key value Pair in the actual response. Key: {item.Key}, Value: {item.Value}", "", Status.failed);
                        }
                    }

                    /*Error: 
                    * Expected Key not found in actual response
                    * Value Mismatch between expected and actual response
                    * Additional KVPairs were found in the actual response*/
                    if(isError)
                    {
                        ScenarioContext.Current["ResultType"] = "ERROR";
                    }
                    else
                    {
                        foreach(var item in expectedRespList)
                        {
                            AllureHelper.ReportEvent($"Validated Key value pair! Key: {item.Key}, Value: {item.Value}", "", Status.passed);
                        }
                        ScenarioContext.Current["ResultType"] = "PASSED";
                    }
                }
            }
        }



        //Compare ActualResponse with the Expected Response in CSV Format
        public void CompareActualVsExpectedResponseFromCsv(object expRespList, object actRespList)
        {
            var expectedRespList = expRespList as List<KeyValuePair<string, string>>;
            var actualRespList = actRespList as List<KeyValuePair<string, string>>;
            var keysFound = new List<string>();
            var valuesNotFound = new List<KeyValuePair<string,string>>();
            var expectedKeys = new List<string>();
            bool valueFound = false;
            bool isError = false;

            if (expectedRespList != null)
                for (var i = 0; i < expectedRespList.Count; i++)
                {
                    var searchKey = expectedRespList.ElementAt(i).Key;
                    Regex newsearchKey;
                    if (searchKey.Contains("[]"))
                    {
                        searchKey = Regex.Replace(searchKey, @"\[]", @"\[[0-9]+\]");
                    }

                    newsearchKey = new Regex(searchKey);

                    if (actualRespList != null)
                        for (var j = 0; j < actualRespList.Count; j++)
                        {
                            if (newsearchKey.IsMatch(actualRespList.ElementAt(j).Key))
                            {
                                keysFound.Add(expectedRespList.ElementAt(i).Key);

                                if (actualRespList.ElementAt(j).Value == expectedRespList.ElementAt(i).Value)
                                {
                                    valueFound = true;
                                    break;
                                }
                                else
                                {
                                    valueFound = false;
                                }
                            }
                        }


                    if (!valueFound)
                    {
                        valuesNotFound.Add(new KeyValuePair<string, string>(expectedRespList.ElementAt(i).Key,
                            expectedRespList.ElementAt(i).Value));
                    }
                }

            if (expectedRespList != null)
                foreach (var item in expectedRespList)
                {
                    expectedKeys.Add(item.Key);
                }

            var keysNotFound = expectedKeys.Except(keysFound);

            foreach(var key in keysNotFound)
            {
                isError = true;
                Console.WriteLine($"Key Not Found! Expected Key: {key}");
                AllureHelper.ReportEvent($"Key Not Found! Expected Key: {key}", "", Status.failed);
            }


            if (valuesNotFound.Count != 0)
            {
                isError = true;
                Console.WriteLine("The following values are not found in the actual response: ");
                foreach (var item in valuesNotFound)
                {
                    Console.WriteLine($"Expected Value for the key \"{item.Key}\" is not found in the actual Response! Expected Value: {item.Value}");
                    AllureHelper.ReportEvent($"Expected Value for the key \"{item.Key}\" is not found in the actual Response! Expected Value: {item.Value}", "", Status.failed);
                }
            }

            /*Error: 
             * Expected Key not found in actual response
             * Value Mismatch between expected and actual response*/
            if (isError)
            {
                ScenarioContext.Current["ResultType"] = "ERROR";
            }
            else
            {
                foreach (var item in expectedRespList)
                {
                    AllureHelper.ReportEvent($"Validated Key value pair! Key: {item.Key}, Value: {item.Value}", "", Status.passed);
                }
                ScenarioContext.Current["ResultType"] = "PASSED";
            }

        }





        //Translate Dictionary to a List
        public List<KeyValuePair<string,string>> DictionaryToList(ref Dictionary<string,object> objDictionary, string parentKey, int listCount, int dictCount)
        {

            foreach (var item in objDictionary)
            {
                
                //Value of a Dictionary Item ==> "null"
                if (item.Value == null)
                {
                    if (parentKey != null)
                    {
                        _jsonResponseList.Add(new KeyValuePair<string, string>(parentKey + "." + item.Key, null));
                    }
                    else
                    {
                        _jsonResponseList.Add(new KeyValuePair<string, string>(item.Key, null));
                    }
                }
                //Value Type of a Dictionary Item ==> "String" or "decimal" or "int"
                else if ((item.Value is string) || (item.Value is decimal) || (item.Value is int))
                {
                    if (parentKey != null)
                    {
                        _jsonResponseList.Add(new KeyValuePair<string, string>(parentKey + "." + item.Key, item.Value.ToString()));
                    }
                    else
                    {
                        _jsonResponseList.Add(new KeyValuePair<string, string>(item.Key, item.Value.ToString()));
                    }

                }
                //Value Type a Dictionary Item ==> "ArrayList"
                else if (item.Value.GetType() == typeof(ArrayList))
                {
                    
                    ArrayList listItem = (item.Value) as ArrayList;

                    /* list_count : In the Initial Call, it is set to 0 and then it is updated based on Total number of objects in the current ArrayList
                     * parent_Key : In the Initial Call , parent_Key is set to null, then it is updated based on key combination of the Current item in the List/Dictionary */
            if (listCount == 0)
            {
                if (listItem != null) listCount = listItem.Count;
            }

                    parentKey = ConstructParentKey(parentKey, item.Key);

                    // Array List is Empty
                    if (listItem != null && listItem.Count == 0)
                    {
                        _jsonResponseList.Add(new KeyValuePair<string, string>(parentKey+"[]", "Empty"));
                    }
                    else
                    {
                        if (listItem != null)
                            for (var i = 0; i < listItem.Count; i++)
                            {
                                string tempParKey = String.Concat(parentKey, "[", i, "]");

                                //The Value type of an ArrayList Item ==> "String" or "Decimal" or "Int"
                                if ((listItem[i] is string) ||
                                    (listItem[i] is decimal) ||
                                    (listItem[i] is int))
                                {
                                    _jsonResponseList.Add(
                                        new KeyValuePair<string, string>(tempParKey, listItem[i].ToString()));
                                }
                                //The Value type of an ArrayList Item ==> "Dictionary<string,object>"
                                else if (listItem[i].GetType() == typeof(Dictionary<string, object>))
                                {
                                    var subDictionary = listItem[i] as Dictionary<string, object>;
                                    DictionaryToList(ref subDictionary, tempParKey, listCount, dictCount);
                                }
                            }

                        listCount = 0;
                    }
                    //End Of the Current Array List , hence Trim the ParentKey to one level up
                    parentKey = TrimLastChildFromParentKey(parentKey);
                }
                //Value Type a Dictionary Item ==> "Dictionary<string,object>"
                else
                {
                    if (item.Value.GetType() == typeof(Dictionary<string,object>))
                    {
                        Dictionary<string, object> subDict = (item.Value) as Dictionary<string, object>;

                        if (subDict != null)
                        {
                            dictCount = subDict.Count;

                            parentKey = ConstructParentKey(parentKey, item.Key);

                            //Dictionary is Empty
                            if (subDict.Count == 0)
                            {
                                _jsonResponseList.Add(new KeyValuePair<string, string>(parentKey, "Empty"));
                            }
                            else
                            {
                                DictionaryToList(ref subDict, parentKey, listCount, dictCount);
                                dictCount = 0;
                            }
                        }
                    }
                    //End Of the Current Dictionary, hence Trim the ParentKey to one level up
                    parentKey = TrimLastChildFromParentKey(parentKey);

                }

            }
            return _jsonResponseList;
        }



        // Trim the last SubKey from the Parent Key at the end of a Dictionary/ArrayList
        private string TrimLastChildFromParentKey(string parKey)
        {
            var tempVal = parKey.LastIndexOf(".", StringComparison.Ordinal);
            if (tempVal != -1)
            {
                parKey = parKey.Remove(tempVal);
            }
            else
            {
                parKey = null;
            }
            return parKey;
        }



        //Extract the last child key from the parent key combination
        private string ExtractLastChildKey(string parKey)
        {
            var tempVal = parKey.LastIndexOf(".", StringComparison.Ordinal);
            string childKey;

            if (tempVal != -1)
            {
                childKey = parKey.Substring(tempVal+1);
            }
            else
            {
                childKey = parKey;
            }
            return childKey;

        }



        // Build the Parent Key Combination Eg: ParentKey.SubKey1.SubKey2 etc
        private string ConstructParentKey(string pKey,string subKey)
        {
            string tempKey;
            if (pKey != null)
            {
                tempKey = String.Concat(pKey, ".", subKey);
            }
            else
            {
                tempKey = subKey;
            }

            return tempKey;
        }



        //Validate expected key and value in the response based on a unique key (such as ID)
        public void ValidateKvPairByUniqueValue(string expKey, string expVal, string uniqueKey,string value,object actRespList)
        {
            var actualRespList = actRespList as List<KeyValuePair<string, string>>;
            bool keyNotFound = true;
            bool isError = true;

            //var searchKey = new Regex(@"Data.Accounts\[[0-9]+\].AccountId");

            var uniqsearchKey = Regex.Replace(uniqueKey,@"\[]", @"\[[0-9]+\]");

            var newuniqsearchKey = new Regex(uniqsearchKey);

            var uniqKeySearchQuery = from kvPair in actualRespList
                                where newuniqsearchKey.IsMatch(kvPair.Key)
                                select kvPair;

            foreach(var item in uniqKeySearchQuery)
            {
                if(item.Value== value)
                {
                    uniqueKey = item.Key;
                    break;
                }
            }

            var newParKey = TrimLastChildFromParentKey(uniqueKey);

            var newExpKey = String.Concat(newParKey,".", ExtractLastChildKey(expKey));

            if (actualRespList != null)
                foreach (var item in actualRespList)
                {
                    if (item.Key == newExpKey)
                    {
                        keyNotFound = false;
                        if (item.Value == expVal)
                        {
                            isError = false;
                            break;
                        }
                        else
                        {
                            AllureHelper.ReportEvent($"The Expected Value does not match! ExpectedValue: {expVal}, ActualValue: {item.Value}", "", Status.failed);
                            Console.WriteLine(
                                $"The Expected Value does not match! ExpectedValue: {expVal}, ActualValue: {item.Value}");
                            break;
                        }
                    }
                }

            if(keyNotFound)
            {
                AllureHelper.ReportEvent($"The Expected Key : {expKey} is not found in the actual response!", "", Status.failed);
                Console.WriteLine($"The Expected Key : {expKey} is not found in the actual response!");
            }

            /*Error: 
            * Expected Key not found in actual response
            * Value Mismatch between expected and actual response*/
            if (isError)
            {
                ScenarioContext.Current["ResultType"] = "ERROR";
            }
            else
            {
                ScenarioContext.Current["ResultType"] = "PASSED";
            }

        }

    }
}
