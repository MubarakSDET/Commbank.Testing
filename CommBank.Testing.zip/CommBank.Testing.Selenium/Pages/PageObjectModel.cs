﻿using System;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace CommBank.Testing.Selenium.Pages
{
    public class PageObjectModel
    {
        private readonly IJavaScriptExecutor _javaScriptExecutor;
        private readonly INavigation _navigator;
        protected readonly TimeSpan DefaultWait = TimeSpan.FromSeconds(30);
        protected readonly IWebDriver Driver;
        protected readonly TimeSpan PollingInterval = TimeSpan.FromMilliseconds(500);

        public PageObjectModel() : this(WebDriverServiceLocator.Driver)
        {
        }

        public PageObjectModel(IWebDriver driver)
        {
            Driver = driver;
            driver = driver ?? throw new ArgumentNullException(nameof(driver));

            _navigator = driver.Navigate();
            _javaScriptExecutor = (IJavaScriptExecutor) driver;

            PageFactory.InitElements(this, new RetryingElementLocator(driver, DefaultWait, PollingInterval));
        }

        public string Url => Driver.Url;

        public IWebElement FindElementIfExists(By by) => Driver.FindElements(by).Count >= 1 ? Driver.FindElements(by).First() : null;

        protected void ExecuteScript(string script)
        {
            _javaScriptExecutor.ExecuteAsyncScript(script);
        }

        protected void GoToUrl(string uri)
        {
            _navigator.GoToUrl(uri);
        }

        protected void ScrollToElement(IWebElement element)
        {
            _javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView();", element);
        }

        //TODO: It throw an exception when element is not visible
        protected void WaitForElementToBecomeVisibleByCss(string cssSelectorToFind)
        {
            new WebDriverWait(Driver, DefaultWait)
                .Until(ExpectedConditions.ElementIsVisible(
                    By.CssSelector(cssSelectorToFind)));
        }

        protected void WaitForUrlToContain(string url)
        {
            new WebDriverWait(Driver, DefaultWait)
                .Until(ExpectedConditions.UrlContains(url));
        }
    }
}