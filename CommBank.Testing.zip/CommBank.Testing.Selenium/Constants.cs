﻿namespace CommBank.Testing.Selenium
{
    public static class Constants
    {
        public class FeatureTags
        {
            public const string LoginOnceWithDefaultCredentials = "LoginOnceWithDefaultCredentials";
        }
    }
}