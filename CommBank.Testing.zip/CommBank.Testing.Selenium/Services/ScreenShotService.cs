﻿using System;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using CommBank.Testing.Selenium.Drivers;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;

namespace CommBank.Testing.Selenium.Services
{
    public class ScreenShotService : IDisposable
    {
        private RemoteWebDriver _webDriver;
        public RemoteWebDriver WebDriver => _webDriver ?? (_webDriver = CreateDriver());

        public void Dispose() => WebDriver?.Dispose();

        public async Task<FileInfo> TakeScreenShot(Uri uri, FileInfo file, Func<IWebDriver, IWebElement> waitCondition = null, TimeSpan? delay = null)
        {
            file.Directory?.Create();

            WebDriver.Navigate().GoToUrl(uri);

            if (waitCondition != null)
                ((IWait<IWebDriver>) new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30.00)))
                    .Until(waitCondition);

            if (delay != null) await Task.Delay(delay.Value);

            WebDriver.TakeScreenshot().SaveAsFile(file.FullName, ScreenshotImageFormat.Jpeg);

            return file;
        }

        private static RemoteWebDriver CreateDriver()
        {
            var webDriver = new ChromeDriverPortable();
            webDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(90);
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);
            webDriver.Manage().Window.Size = new Size(1280, 1024);

            return webDriver;
        }
    }
}