﻿using System;
using System.Collections.Generic;
using System.IO;
using CsvHelper;
using NUnit.Framework;
using TechTalk.SpecFlow;
using static TechTalk.SpecFlow.FeatureContext;
#pragma warning disable 618

namespace CommBank.Testing.Selenium.Services
{
    public class DataService
    {
        /// <summary>
        /// Parses CSV file at the given path and stores each row in the file into the FeatureContext with the Key (csvHeaderName).
        /// Recommend using "TestCaseName" as the first column in the Csv File and pass that as csvRowTitle. 
        /// </summary>
        /// <param name="csvPath">CSV File Path</param>
        /// <param name="csvHeaderName">Unique Key/Column Name to identify each row. Typical example is "TestCaseName"</param>
        public static void LoadDataFromCsvToFeatureContext(string csvPath, string csvHeaderName)
        {
            Dictionary<string, string> testData = new Dictionary<string, string>();
            var reader = File.OpenText(csvPath);
            var csv = new CsvReader(reader);
            csv.Read();
            csv.ReadHeader();
            try
            {
                while (csv.Read())
                {
                    for (int i = 0; csv.TryGetField(i, out string value); i++)
                    {
                        var key = csv.Context.HeaderRecord[i];
                        testData.Add(key, value);
                    }

                    if (Current != null)
                        Current[csv.GetField<string>(csvHeaderName)] = new Dictionary<string, string>(testData);
                    testData.Clear();

                }
                reader.Close();
            }
            catch (Exception)
            {
                reader.Close();
            }
        }

        public static string GetTestData(string key)
        {
            try
            {
                var scenarioData = new Dictionary<string, string>(Current[ScenarioContext.Current.ScenarioInfo.Title] as IDictionary<string, string> ?? throw new InvalidOperationException());
                return scenarioData[key];
            }
            catch (Exception e)
            {
                Assert.Fail("Unable to find data in the FeatureContext: " + Current.FeatureInfo.Title + " using the Scenario Title: " + ScenarioContext.Current.ScenarioInfo.Title);
                return "ERROR";
            }

        }
    }
}
