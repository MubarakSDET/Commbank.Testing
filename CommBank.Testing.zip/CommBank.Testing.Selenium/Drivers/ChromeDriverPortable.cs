﻿using OpenQA.Selenium.Chrome;

namespace CommBank.Testing.Selenium.Drivers
{
    public class ChromeDriverPortable : ChromeDriver
    {
        public ChromeDriverPortable() : base(ChromeDriverOptions.ChromePortableOptions)
        {
        }
    }
}