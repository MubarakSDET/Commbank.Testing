﻿using OpenQA.Selenium.Firefox;

namespace CommBank.Testing.Selenium.Drivers
{
    public class FirefoxDriver : OpenQA.Selenium.Firefox.FirefoxDriver
    {
        private static readonly FirefoxOptions FirefoxOptions = new FirefoxOptions
        {
            AcceptInsecureCertificates = true
        };

        public FirefoxDriver() : base(FirefoxOptions)
        {
        }
    }
}