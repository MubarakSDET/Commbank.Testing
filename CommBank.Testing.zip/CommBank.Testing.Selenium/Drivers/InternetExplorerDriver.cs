﻿using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommBank.Testing.Selenium.Drivers
{
    public class InternetExplorerDriver : OpenQA.Selenium.IE.InternetExplorerDriver
    {
        //private static readonly InternetExplorerOptions ieo = new InternetExplorerOptions
        //{
        //    //var ieOptions = new OpenQA.Selenium.IE.InternetExplorerOptions();
        //    ieOptions.IgnoreZoomLevel = true;
        //    ieOptions.UnexpectedAlertBehavior = OpenQA.Selenium.IE.InternetExplorerUnexpectedAlertBehavior.Accept;
        //};
        //public InternetExplorerDriver() : base(InternetExplorerOptions)
        //{
        //}
    }
}