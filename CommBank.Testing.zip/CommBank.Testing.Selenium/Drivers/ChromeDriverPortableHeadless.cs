﻿using OpenQA.Selenium.Chrome;

namespace CommBank.Testing.Selenium.Drivers
{
    public class ChromeDriverPortableHeadless : ChromeDriver
    {
        public ChromeDriverPortableHeadless() : base(ChromeDriverOptions.ChromePortableHeadlessOptions)
        {
        }
    }
}