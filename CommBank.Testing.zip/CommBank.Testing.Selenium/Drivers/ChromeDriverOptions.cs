﻿using System.Collections.Generic;
using CommBank.Testing.Selenium.Infrastructure.Extensions;
using OpenQA.Selenium.Chrome;

namespace CommBank.Testing.Selenium.Drivers
{
    public static class ChromeDriverOptions
    {
        private static readonly List<string> Arguments = new List<string>
        {
            "--test-type",
            "--disable-extensions",
            "--start-maximized",
            "--ignore-certificate-errors"
        };

        public static ChromeOptions ChromePortableHeadlessOptions => ChromePortableOptions.ConfigureChromeHeadlessOptions();

        public static ChromeOptions ChromePortableOptions => ChromeOptionExtensions.AddArguments(new ChromeOptions
            {
                LeaveBrowserRunning = false,
                AcceptInsecureCertificates = true
            }, Arguments.ToArray())
            .ConfigureChromeExecutablePath();

        public static ChromeOptions ChromeOptions => ChromeOptionExtensions.AddArguments(new ChromeOptions
        {
            LeaveBrowserRunning = false,
            AcceptInsecureCertificates = true,
        }, Arguments.ToArray());
    }
}