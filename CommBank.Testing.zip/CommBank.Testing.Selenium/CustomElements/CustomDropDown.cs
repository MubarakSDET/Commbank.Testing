﻿using System.Linq;
using OpenQA.Selenium;

namespace CommBank.Testing.Selenium.CustomElements
{
    public static class SelectExtensions
    {
        public static CustomDropDown ToCustomDropDown(this string selector) => new CustomDropDown(selector);
    }

    public class CustomDropDown
    {
        private readonly string _baseSelector;
        private readonly IWebDriver _driver;

        public CustomDropDown(string baseSelector) : this(WebDriverServiceLocator.Driver, baseSelector)
        {
        }

        public CustomDropDown(IWebDriver driver, string baseSelector)
        {
            _driver = driver;
            _baseSelector = baseSelector;
        }

        public void Select(string value)
        {
            _driver
                .FindElement(By.CssSelector(_baseSelector + " ~ i"))
                .Click();

            _driver
                .FindElements(By.CssSelector($"{_baseSelector} + * + div > ul.result-list li"))
                .Where(option => option.Text.Trim() == value).ToList()
                .ForEach(option => option.Click());
        }
    }
}