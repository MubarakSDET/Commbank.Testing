﻿namespace CommBank.Testing.Selenium.Locators
{
    public class WebElementLocators
    {
        public static class LoginPage
        {
            public const string ClientIdTextCss = "#ctl00_cpContent_txtLogin";
            public const string LoginButtonCss = "#ctl00_cpContent_btnLogin";
            public const string PasswordTextCss = "#ctl00_cpContent_txtPassword";
        }
    }
}