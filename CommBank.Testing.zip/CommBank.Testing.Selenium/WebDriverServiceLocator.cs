﻿using System;
using System.Linq;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace CommBank.Testing.Selenium
{
    public static class WebDriverServiceLocator
    {
        public static readonly Func<bool> FeatureDriverIsAvailable = () => FeatureContext.Current != null && FeatureContext.Current.ContainsKey("Driver");
        public static readonly Func<bool> GlobalDriverIsAvailable = () => GlobalDriver != null;
        public static bool DriverIsAvailable => ScenarioDriverIsAvailable() || FeatureDriverIsAvailable() || GlobalDriverIsAvailable();

        public static IWebDriver GlobalDriver;


        private static readonly Func<bool> ScenarioDriverIsAvailable = () => ScenarioContext.Current != null && ScenarioContext.Current.Keys.Contains("Driver");

        public static IWebDriver Driver =>
            ScenarioDriverIsAvailable() ? (IWebDriver) ScenarioContext.Current["Driver"]
            : FeatureDriverIsAvailable() ? (IWebDriver) FeatureContext.Current["Driver"]
            : GlobalDriverIsAvailable() ? GlobalDriver
            : throw new ArgumentException("Please initialize the WebDriver from either your FeatureContext / ScenarioContext Hooks or Globally.");

    }
}