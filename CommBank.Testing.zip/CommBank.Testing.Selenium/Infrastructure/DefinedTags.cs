﻿namespace CommBank.Testing.Selenium.Infrastructure
{
    public static class DefinedTags
    {
        public const string RequiresABrowser = "RequiresABrowser";
    }
}