﻿using System;

namespace CommBank.Testing.Selenium.Infrastructure
{
    public static class EnvironmentSettings
    {
        public static bool IsRunningOnTeamCityAgent => Environment.GetEnvironmentVariable("TEAMCITY_VERSION") != null;
    }
}