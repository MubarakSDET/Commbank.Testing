﻿using System;

namespace CommBank.Testing.Selenium.Infrastructure
{
    public class StandardOutputLogger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine(message);
        }
    }

    public interface ILogger
    {
        void Log(string message);
    }
}