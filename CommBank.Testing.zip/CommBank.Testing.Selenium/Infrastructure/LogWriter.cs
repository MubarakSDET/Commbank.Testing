﻿using System;

namespace CommBank.Testing.Selenium.Infrastructure
{
    public class LogWriter
    {
        private readonly ILogger _logger;

        public LogWriter() : this(new StandardOutputLogger())
        {
        }

        public LogWriter(ILogger logger) => _logger = logger;

        public void Log(string value, string expectedValue, string actualValue)
        {
            _logger.Log("!-------------------------------------------------------------------------");
            _logger.Log("    ");
            _logger.Log($"Expected {value} : {expectedValue}");
            _logger.Log($"Actual   {value} : {actualValue}");
            _logger.Log("    ");
            _logger.Log("#-------------------------------------------------------------------------");
        }

        public void Log(string value, string expectedValue, string actualValue, bool isDecimal)
        {
            _logger.Log("!-------------------------------------------------------------------------");
            _logger.Log("    ");
            _logger.Log($"Expected {value} : {Math.Round(Convert.ToDecimal(expectedValue), 3)}");
            _logger.Log($"Actual   {value} : {Math.Round(Convert.ToDecimal(actualValue), 3)}");
            _logger.Log("    ");
            _logger.Log("#-------------------------------------------------------------------------");
        }

        public void Log(string logData)
        {
            _logger.Log("!-------------------------------------------------------------------------");
            _logger.Log(logData);
            _logger.Log("#-------------------------------------------------------------------------");
        }
    }
}