﻿using System.IO;
using System.Reflection;
using CommBank.Testing.Extensions;
using OpenQA.Selenium.Chrome;

namespace CommBank.Testing.Selenium.Infrastructure.Extensions
{
    public static class ChromeOptionExtensions
    {
        private static string AssemblyDirectory { get; set; }  =Assembly.GetExecutingAssembly().GetLocation();

        public static ChromeOptions AddArguments(this ChromeOptions options, string[] args)
        {
            options.AddArguments(args);
            options.AddAdditionalCapability("useAutomationExtension", false);
            return options;
        }

        public static ChromeOptions ConfigureChromeExecutablePath(this ChromeOptions options)
        {
            var chromeExePath = $@"{AssemblyDirectory}\GoogleChromePortable_77\App\Chrome-bin\chrome.exe";

            if (!File.Exists(chromeExePath))
            {
                var message = $@"Can't locate Chrome Portable @'{chromeExePath}'
                                Current Executing Assembly Location is '{AssemblyDirectory}'";

                throw new FileNotFoundException(message);
            }

            options.BinaryLocation = chromeExePath;

            //Handle failed to load extension from chrome issue
            options.AddAdditionalCapability("useAutomationExtension", false);

            return options;
        }

        public static ChromeOptions ConfigureChromeHeadlessOptions(this ChromeOptions options)
        {
            options.AddArgument("--headless");
            options.AddArgument("--diable-gpu");

            return options;
        }
    }
}