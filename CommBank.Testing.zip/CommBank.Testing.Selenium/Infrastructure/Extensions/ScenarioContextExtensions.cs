﻿using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Reflection;
using CommBank.Testing.Extensions;
using TechTalk.SpecFlow;

namespace CommBank.Testing.Selenium.Infrastructure.Extensions
{
    public static class SpecFlowExtensions
    {
        private static Assembly Assembly => typeof(SpecFlowExtensions).Assembly;

        public static FileInfo ToScreenShotFileName(this ScenarioContext scenarioContext)
        {
            var directoryPath = Directory.CreateDirectory(
                    Path.Combine(
                        Assembly.GetArtifactsFolder(),
                        "ScreenShots"))
                .FullName;

            var fileName = scenarioContext.ToFileName().RemoveInvalidFileNameCharacters();
            fileName = Path.Combine(
                    directoryPath,
                    $"{fileName}.png")
                .Replace("/", "");

            if (fileName.Length > 255) fileName = fileName.Substring(0, 255);

            return new FileInfo(fileName);
        }

        [SuppressMessage("ReSharper", "PossibleNullReferenceException")]
        private static long ElapsedMilliseconds(this ScenarioContext context) => ((Stopwatch) typeof(ScenarioContext)
                .GetProperty("Stopwatch", BindingFlags.Instance | BindingFlags.NonPublic)
                .GetValue(context))
            .ElapsedMilliseconds;

        [SuppressMessage("ReSharper", "PossibleNullReferenceException")]
        private static long ElapsedMilliseconds(this FeatureContext context) => ((Stopwatch) typeof(FeatureContext)
                .GetProperty("Stopwatch", BindingFlags.Instance | BindingFlags.NonPublic)
                .GetValue(context))
            .ElapsedMilliseconds;

        private static string ToFileDescription(this StepInfo stepInfo)
        {
            var stepDefinitionType = stepInfo.StepDefinitionType.ToString();
            var stepTitle = stepInfo.Text.Replace(" ", "_");

            return $"{stepDefinitionType}_{stepTitle}";
        }

        private static string ToFileName(this ScenarioContext context) =>
            $"{context.ToJiraReference()}_{FeatureContext.Current.ElapsedMilliseconds()}_{context.StepContext.StepInfo.ToFileDescription()}"
                .Replace("<", "").Replace(">", "");

        private static string ToJiraReference(this ScenarioContext scenarioContext)
        {
            var title = scenarioContext.ScenarioInfo.Title;
            var jiraInTitle = title.Split('-')[0].StartsWith("CB");
            if (jiraInTitle) return title.Split('-')[0];

            var allJiraTags = FeatureContext.Current.FeatureInfo.Tags.Union(scenarioContext.ScenarioInfo.Tags)
                .Where(tag => tag.StartsWith("CB", StringComparison.InvariantCultureIgnoreCase))
                .ToList();
            var tagsContainJira = allJiraTags.Any();
            if (tagsContainJira) return string.Join("_", allJiraTags);

            return $"{title.Substring(0, title.Length >= 50 ? 50 : title.Length).Trim()}";
        }
    }
}