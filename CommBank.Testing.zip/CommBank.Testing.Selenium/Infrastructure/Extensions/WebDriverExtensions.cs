﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using CommBank.Testing.Selenium.Infrastructure.WebClients;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using Cookie = OpenQA.Selenium.Cookie;

namespace CommBank.Testing.Selenium.Infrastructure.Extensions
{
    public static class WebDriverExtensions
    {
        public static int WaitTime { set; get; } = 20; // this is the default value of wait time
        public static int counter = 3;

        public static string ExecuteScript(this IWebDriver driver, string script, params object[] args) => ((IJavaScriptExecutor) driver).ExecuteScript(script, args).ToString();

        public static bool Exists(this By by) => WebDriverServiceLocator.Driver.FindElements(by).Count != 0;

        public static string GetInnerHtml(this IWebDriver driver, IWebElement element) => driver.ExecuteScript("return arguments[0].innerHTML;", element);

        public static WebClient GetWebClient(this IWebDriver webDriver) => CookieAwareWebClient.CreateWebClient(webDriver.ToCookieContainer());

        public static CookieContainer ToCookieContainer(this IWebDriver webDriver) => webDriver.Manage().Cookies.AllCookies.ToCookieContainer();

        private static CookieContainer ToCookieContainer(this IEnumerable<Cookie> from) => from.ToList().ToCookieContainer();

        private static CookieContainer ToCookieContainer(this List<Cookie> from)
        {
            var cookieContainer = new CookieContainer {PerDomainCapacity = 60};

            foreach (var existingCookie in from)
            {
                // our cookies contain invalid characters
                // so we add a cookie with no value
                var cookie = new System.Net.Cookie(existingCookie.Name, existingCookie.Value, existingCookie.Path, existingCookie.Domain ?? "dev01.commsec-it.cba");
                cookieContainer.Add(cookie);
            }

            //// now we need to patch the values of all cookies
            //from.Select(x => x.Domain)
            //    .Distinct()
            //    .ToList()
            //    .ForEach(domain =>
            //    {
            //        domain = domain.StartsWith(".") ? $"www{domain}" : domain;

            //        var cookieCollection = cookieContainer.GetCookies(new Uri($"http://{domain}"));
            //        foreach (Cookie cookie in cookieCollection)
            //        {
            //            cookie.Value = from.Single(x => x.Name == cookie.Name).Value;
            //        }
            //    });

            return cookieContainer;
        }

        public static void WaitForPageLoad(this IWebDriver driver, int intTimeout)
        {
            DateTime timeOnFunctionCall = DateTime.Now;
            string strState;

            while ((DateTime.Now - timeOnFunctionCall).TotalSeconds < intTimeout)
            {
                var js = (IJavaScriptExecutor)driver;
                try
                {
                    strState = (string)js.ExecuteScript("return document.readyState");
                    if (strState == "complete")
                    {
                        Thread.Sleep(TimeSpan.FromSeconds(1));
                        return;
                    }
                    Thread.Sleep(TimeSpan.FromSeconds(1));
                }
                catch (Exception)
                {
                    Thread.Sleep(TimeSpan.FromSeconds(3));
                    return;
                }
            }
        }
        public static void WaitForPageToLoad(IWebDriver driver, int timeoutSec)
        {
            var currentDate = DateTime.UtcNow;
            var js = (IJavaScriptExecutor)driver;
            var state = (string)js.ExecuteScript("return document.readyState");
            while (!state.Equals("complete"))
            {
                if (DateTime.UtcNow > currentDate.AddSeconds(timeoutSec))
                    break;
            }
            DefaultWait<IWebDriver> wait = new DefaultWait<IWebDriver>(driver);
            wait.Timeout = TimeSpan.FromSeconds(WaitTime);
            wait.PollingInterval = TimeSpan.FromMilliseconds(5);
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException));
            wait.Until(wd => (wd as IJavaScriptExecutor).ExecuteScript("return document.readyState")).Equals("complete");
            //wait.Until(wd => (wd as IJavaScriptExecutor).ExecuteScript("return (document.readyState == 'complete' && jQuery.active == 0)"));
        }

        public static void WaitForPageLoadAdvanced(this IWebDriver driver, int intTimeout)
        {
            try
            {
                DateTime timeOnFunctionCall = DateTime.Now;
                string strState;
                var js = (IJavaScriptExecutor)driver;


                ReadOnlyCollection<IWebElement> iFrames = driver.FindElements(By.TagName("iframe"));

                if (iFrames.Count == 0)
                {
                    while ((DateTime.Now - timeOnFunctionCall).TotalSeconds < intTimeout)
                    {
                        try
                        {
                            strState = (string)js.ExecuteScript("return document.readyState");
                            if (strState == "complete")
                            {
                                Thread.Sleep(TimeSpan.FromSeconds(2));
                                return;
                            }
                            Thread.Sleep(TimeSpan.FromSeconds(1));
                        }
                        catch (Exception)
                        {
                            Thread.Sleep(TimeSpan.FromSeconds(2));
                            return;
                        }
                    }
                    Thread.Sleep(TimeSpan.FromSeconds(1));
                    return;
                }

                foreach (var iframe in iFrames)
                {
                    if ((iframe.GetAttribute("id") != string.Empty) && iframe.Displayed)
                    {
                        timeOnFunctionCall = DateTime.Now;
                        while ((DateTime.Now - timeOnFunctionCall).TotalSeconds < intTimeout)
                        {
                            try
                            {
                                strState =
                                    (string)js.ExecuteScript("return arguments[0].contentDocument.readyState", iframe);
                                if (strState == "complete")
                                {
                                    Thread.Sleep(TimeSpan.FromSeconds(2));
                                    return;
                                }
                                Thread.Sleep(TimeSpan.FromSeconds(1));
                            }
                            catch (Exception)
                            {
                                Thread.Sleep(TimeSpan.FromSeconds(2));
                                return;
                            }
                        }
                    }
                }
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        /// <summary>
        /// The below Method can be used for below 2 ways:-
        /// 1 :- Close a single broswer window by sending an empty value (Ex:- closeBroswerWindow("")    )
        /// 2 :- Close all browsers by sending an empty value            (Ex:- closeBroswerWindow("All") )
        /// </summary>
        public static void closeBroswerWindow(this IWebDriver driver, string browserVal)
        {
            if (browserVal.Equals(""))
            {
                try
                {
                    driver.Close();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            else if (browserVal.Equals("All"))
            {
                try
                {
                    driver.Quit();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        /// <summary>
        /// The below Method can be used for accepting or dismissing an alert:-
        /// 1 :- In order to accept the alert  (Ex:- getAlert("Accept") )
        /// 2 :- In order to dismiss the alert (Ex:- getAlert("Dismiss") )
        /// </summary>
        /// <param name="actionToPerform"></param>
        public static void getAlert(this IWebDriver driver, string actionToPerform)
        {
            IAlert alert;
            try
            {
                alert = driver.SwitchTo().Alert();
                if (actionToPerform.Equals("Accept"))
                {
                    alert.Accept();
                }
                else if (actionToPerform.Equals("Dismiss"))
                {
                    alert.Dismiss();
                }
            }
            catch (Exception ex)
            {
                if (ex is NoAlertPresentException || ex is WebDriverException)
                {
                    Console.WriteLine(ex.Message);
                }
                throw;
            }
        }

        /// <summary>
        /// The below method can be used for retreving the text from an alert
        /// </summary>
        /// <returns>string</returns>
        public static string getAlertText(this IWebDriver driver)
        {
            IAlert alert;
            string alertText;
            try
            {
                alert = driver.SwitchTo().Alert();
                alertText = alert.Text;
            }
            catch (Exception ex)
            {
                if (ex is NoAlertPresentException || ex is WebDriverException)
                {
                }
                throw;
            }
            return alertText;
        }

        /// <summary>
        /// The below method can be used for retreving the attributes of an webelement
        /// </summary>
        /// <param name="ele"></param>
        /// <param name="attribute"></param>
        /// <returns>string</returns>
        public static string getAttributes(this IWebElement element, string attribute)
        {
            string attVal = "";
            try
            {
                attVal = element.GetAttribute(attribute);
            }
            catch (WebDriverException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return attVal;
        }

        /// <summary>
        /// This method can be used for switching to a child window from parent window using index
        /// ex:- switchToWindowUsingIndex(1);
        /// </summary>
        /// <param name="index"></param>
        public static void switchToWindowUsingIndex(this IWebDriver driver, string index)
        {
            try
            {
                driver.SwitchTo().Window(index);
            }
            catch (Exception ex)
            {
                if (ex is NoSuchWindowException || ex is WebDriverException)
                {
                    Console.WriteLine(ex.Message);
                }
                throw;
            }
        }

        /// <summary>
        /// This method can be used for switching to a frame
        /// ex:-switchToFrame(elementID)
        /// </summary>
        /// <param name="element"></param>
        public static void switchToFrame(this IWebDriver driver, IWebElement element)
        {
            try
            {
                driver.SwitchTo().Frame(element);
                Thread.Sleep(15000); //waiting for frame to swtich 
            }
            catch (Exception ex)
            {
                if (ex is NoSuchWindowException || ex is WebDriverException)
                {
                    Console.WriteLine(ex.Message);
                }
                throw;
            }
        }

        public static IList<IWebElement> findAllFrame(IWebDriver driver, string webElement)
        {
            IList<IWebElement> iframes = driver.FindElements(By.Name(webElement));
            return iframes;
        }

        /// <summary>
        /// This method can be used to verify if the given webelement is selected
        /// </summary>
        /// <param name="element"></param>
        /// <returns>boolean</returns>
        public static bool verifyItemSelected(this IWebDriver driver, IWebElement element)
        {
            bool val = false;
            try
            {
                Thread.Sleep(1500);
                if (element.Selected)
                {
                    val = true;
                }
                //val = element.Selected;
            }
            catch (WebDriverException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return val;
        }

        /// <summary>
        /// Mehtod to read contents from data table
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="elementXPath"></param>
        public static void readDataTable(this IWebDriver driver, string elementXPath)
        {
            // xpath of html table
            var elemTable = driver.FindElement(By.XPath(elementXPath));

            // Fetch all Row of the table
            IList<IWebElement> lstTrElem = new List<IWebElement>(elemTable.FindElements(By.TagName("tr")));
            string strRowData = "";

            // Traverse each row
            foreach (var elemTr in lstTrElem)
            {
                // Fetch the columns from a particuler row
                List<IWebElement> lstTdElem = new List<IWebElement>(elemTr.FindElements(By.TagName("td")));
                if (lstTdElem.Count > 0)
                {
                    // Traverse each column
                    foreach (var elemTd in lstTdElem)
                    {
                        // "\t\t" is used for Tab Space between two Text
                        strRowData = strRowData + elemTd.Text + "\t\t";
                    }
                }
                else
                {
                    // To print the data into the console
                    Console.WriteLine("This is Header Row");
                    Console.WriteLine(lstTrElem[0].Text.Replace(" ", "\t\t"));
                }
                Console.WriteLine(strRowData);
                strRowData = string.Empty;
            }
        }

        /// <summary>
        /// Mehtod to locate webelement on webpage
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="locatorOption"></param>
        /// <param name="locVal"></param>
        /// <returns></returns>
        public static IWebElement locateWebElement(this IWebDriver driver, string locatorOption, string locVal)
        {
            IWebElement ele = null;
            try
            {
                switch (locatorOption)
                {
                    case ("id"): return ele = driver.FindElement(By.Id(locVal));
                    case ("link"): return ele = driver.FindElement(By.LinkText(locVal));
                    case ("xpath"): return ele = driver.FindElement(By.XPath(locVal));
                    case ("name"): return ele = driver.FindElement(By.Name(locVal));
                    case ("class"): return ele = driver.FindElement(By.ClassName(locVal));
                    case ("tag"): return ele = driver.FindElement(By.TagName(locVal));
                }
            }
            catch (Exception ex)
            {
                if (ex is NoSuchWindowException || ex is WebDriverException)
                {
                    Console.WriteLine(ex.Message);
                }
                throw;
            }
            return ele;
        }

        /// <summary>
        /// This method is to be used to find element on a web page
        /// </summary>
        /// <param name="timeOutInSeconds"></param>
        /// <param name="by"></param>
        /// <param name="driver"></param>
        /// <returns></returns>
        public static IWebElement FindElement(this IWebDriver driver, int timeOutInSeconds, By by)
        {
            if (timeOutInSeconds > 0)
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
                return wait.Until(drv => drv.FindElement(by));
            }
            return driver.FindElement(by);
        }

        /// <summary>
        /// This function can be used to read data from csv file, return type is List
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <returns>List<string></returns>
        public static List<string> readCSVFile(string strFilePath)
        {
            var reader = new StreamReader(File.OpenRead(strFilePath));
            List<string> searchList = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                searchList.Add(line);
            }
            return searchList;
        }

        /// <summary>
        /// This method can be used to write data to csv file
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <param name="val1"></param>
        /// <param name="val2"></param>
        public static void writeToCSV(string strFilePath, string val1, string val2)
        {
            StringBuilder sbOutput = new StringBuilder();
            string[] existingLines = null;
            try
            {
                existingLines = File.ReadAllLines(strFilePath);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            val2 = val2.Remove(0, 1);
            val2 = RemoveLast(val2, ")");
            string textToBeAdded = val1 + "_" + val2;
            sbOutput.AppendLine(string.Join("\t", textToBeAdded));

            if (existingLines == null)
            {
                // Create and write the csv file
                File.WriteAllText(strFilePath, sbOutput.ToString());
            }
            else if (existingLines != null)
            {
                // To append more lines to the csv file
                File.AppendAllText(strFilePath, sbOutput.ToString());
            }
        }

        /// <summary>
        /// Method to remove characters from the end of string
        /// </summary>
        /// <param name="text"></param>
        /// <param name="character"></param>
        /// <returns></returns>
        public static string RemoveLast(this string text, string character)
        {
            if (text.Length < 1) return text;
            return text.Remove(text.ToString().LastIndexOf(character), character.Length);
        }

        /// <summary>
        /// Method to Select value from drop down
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="ddValue"></param>
        /// <param name="locatorValue"></param>
        /// <param name="locator"></param>
        public static void selectValueFromDropDown(IWebDriver driver, string ddValue, string locatorValue, string locator)
        {
            SelectElement selectElement;
            if (locator.Equals("XPath"))
            {
                selectElement = new SelectElement(driver.FindElement(By.XPath(locatorValue)));
                selectElement.SelectByText(ddValue);
            }
            else if (locator.Equals("Id"))
            {
                selectElement = new SelectElement(driver.FindElement(By.Id(locatorValue)));
                selectElement.SelectByText(ddValue);
            }
        }

        /// <summary>
        /// Method to wait
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="locatorValue"></param>
        public static void WaitMethod(this IWebDriver driver, string locatorValue)
        {
            WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 0, 60));
            bool element = wait.Until(condition =>
            {
                try
                {
                    var elementToBeDisplayed = driver.FindElement(By.XPath(locatorValue));
                    return elementToBeDisplayed.Displayed;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
            });
        }

        /// <summary>
        /// Mehotd for checking if a particular frame has loaded
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="sleepInterval"></param>
        /// <param name="element"></param>
        public static void checkIfFrameIsLoaded(this IWebDriver driver, int sleepInterval, string element)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(sleepInterval));
            wait.Until(ExpectedConditions.FrameToBeAvailableAndSwitchToIt(By.Id(element)));
        }

        /// <summary>
        /// Mehotd to check visiblity of a element in given time frame
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="element"></param>
        /// <param name="timeout"></param>
        public static void WaitForElementToBecomeVisibleWithinTimeout(IWebDriver driver, IWebElement element, int timeout)
        {
            new WebDriverWait(driver, TimeSpan.FromSeconds(timeout)).Until(ElementIsVisible(element));
        }

        /// <summary>
        /// Chekcing if element is visible
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static Func<IWebDriver, bool> ElementIsVisible(IWebElement element)
        {
            return driver => {
                try
                {
                    return element.Displayed;
                }
                catch (Exception)
                {
                    // If element is null, stale or if it cannot be located
                    return false;
                }
            };
        }

        /// <summary>
        /// Function to check if tool tip is present
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="locatorValue"></param>
        /// <param name="expectedToolTipValue"></param>
        /// <returns></returns>
        public static bool VerifyToolTip(this IWebDriver driver, string locatorValue, string expectedToolTipValue)
        {
            bool val = true;
            string toolTipText = "";
            try
            {
                Actions actions = new Actions(driver);
                IWebElement ele = driver.FindElement(By.Id(locatorValue));
                actions.ClickAndHold(ele).Perform();
                toolTipText = ele.Text;
                if (toolTipText.Equals(expectedToolTipValue))
                {
                    val = false;
                }
            }
            catch (WebDriverException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return val;
        }

        /// <summary>
        /// Method to Highlight an webelement 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="element"></param>
        public static void HighLightText(this IWebDriver driver, IWebElement element)
        {
            var jsDriver = (IJavaScriptExecutor)driver;
            string highlightJavascript = @"$(arguments[0]).css({ ""border-width"" : ""2px"", ""border-style"" : ""solid"", ""border-color"" : ""red"", ""background"" : ""yellow"" });";
            jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
        }

        /// <summary>
        /// Mehtod for wait for text of a particular web elment
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="element"></param>
        /// <param name="secs"></param>
        /// <param name="textToBePresent"></param>
        public static void WaitForTheElementText(this IWebDriver driver, By element, int secs, string textToBePresent)
        {
            DefaultWait<IWebDriver> wait = new DefaultWait<IWebDriver>(driver);
            wait.Timeout = TimeSpan.FromSeconds(secs);
            wait.PollingInterval = TimeSpan.FromMilliseconds(5);
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementLocated((element), textToBePresent));
        }

        /// <summary>
        /// Fucniton to check if the webelement exists
        /// </summary>
        /// <param name="elementtocheck"></param>
        /// <returns></returns>
        public static bool DoesElementExist(IWebElement elementtocheck)
        {
            // Wait for element condition: return true if found
            try
            {
                if (elementtocheck.Displayed)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;     // Timeout occurred: fail
            }
        }

        /// <summary>
        /// Checking unchecking of a check box or radio button
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="checkBxRadioElement"></param>
        /// <param name="option"></param>
        public static void checkUncheckItem(this IWebDriver driver, IWebElement checkBxRadioElement, string option)
        {
            try
            {
                if (option.Equals("Check"))
                {
                    if (!checkBxRadioElement.Selected)
                    {
                        checkBxRadioElement.Click();
                        Thread.Sleep(1000);
                    }
                }
                else if (option.Equals("UnCheck"))
                {
                    if (checkBxRadioElement.Selected)
                    {
                        checkBxRadioElement.Click();
                        Thread.Sleep(1000);
                    }
                }
            }
            catch (NoSuchElementException)
            {
            }
        }

        /// <summary>
        /// Checks if Alert is present and returns a boolean value
        /// </summary>
        /// <param name="driver"></param>
        /// <returns>true / false</returns>
        public static bool isAlertPresent(this IWebDriver driver)
        {
            try
            {
                driver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        /// <summary>
        /// automatically removes extra spaces withjin the strings
        /// </summary>
        /// <param name="driver"></param>
        /// <returns>true / false</returns>
        public static string removeExtraSpacesWithinString(string sentence)
        {
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            sentence = regex.Replace(sentence, " ");
            return sentence;
        }
    }
}