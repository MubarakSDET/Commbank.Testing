﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using NUnit.Framework;
using OpenQA.Selenium;

namespace CommBank.Testing.Selenium.Infrastructure.Extensions
{
    public static class WebElementExtensions
    {
        public static void ClickOnElement(this IWebElement cssSelector) => ((IJavaScriptExecutor) WebDriverServiceLocator.Driver).ExecuteScript("arguments[0].click();", cssSelector);
        public static string GetInnerHtml(this IWebElement element, IWebDriver driver) => driver.ExecuteScript("return arguments[0].innerHTML;", element);

        public static IWebElement GetParent(this IWebElement element) => element.FindElement(By.XPath(".."));

        public static void ScrollIntoView(this IWebElement element, IWebDriver driver)
        {
            var js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        public static void ClickWebTableLink(this IWebElement webTable, string strSearchString, IWebDriver driver)
        {
            try
            {
                ReadOnlyCollection<IWebElement> rowData = webTable.FindElements(By.XPath(".//a"));
                for (int i = 0; i < rowData.Count; i++)
                {
                    string textRowData = rowData[i].Text.ToLower();

                    if (textRowData.Contains(strSearchString.ToLower()))
                    {
                        var js = (IJavaScriptExecutor)driver;
                        js.ExecuteScript("arguments[0].click();", rowData[i]);
                        return;
                    }

                }
                Assert.Fail("Unable to find the LinkText: " + strSearchString + " in the table");
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }

        }

        public static IWebElement LocateElementInWebTable(this IWebElement webTable, string xRowColumnIdentifier, string strSearchString,
           int iElementColumn, string strElementType, out string strRes)
        {
            try
            {
                if (!xRowColumnIdentifier.Contains("|"))
                {
                    strRes = "xRowColumnIdentifier does not contain row and column identifier";
                    return null;
                }

                string[] arrTemp = xRowColumnIdentifier.Split('|');
                string xRowIdentifier = arrTemp[0];
                string xColIdentifier = arrTemp[1];


                ReadOnlyCollection<IWebElement> rowCollection = webTable.FindElements(By.XPath(".//" + xRowIdentifier));
                IWebElement targetRowElement = null;

                for (int i = 0; i < rowCollection.Count; i++)
                {
                    string textRowData = rowCollection[i].Text.ToLower();

                    if (textRowData.Contains(strSearchString.ToLower()))
                    {
                        targetRowElement = rowCollection[i];
                        break;
                    }

                }
                if (targetRowElement == null)
                {
                    strRes = "Could not find the text:" + strSearchString + " in the table. ";
                    return null;
                }

                ReadOnlyCollection<IWebElement> colCollection =
                    targetRowElement.FindElements(By.XPath(".//" + xColIdentifier));

                for (int c = 0; c < colCollection.Count; c++)
                {
                    if (c == (iElementColumn - 1))
                    {
                        IWebElement targetElement;
                        switch (strElementType.ToLower())
                        {
                            case "input":
                                targetElement = colCollection[c].FindElement(By.TagName("Input"));
                                break;
                            case "button":
                                targetElement = colCollection[c].ReturnInputElementByTypeAttribute("submit") ??
                                                colCollection[c].ReturnInputElementByTypeAttribute("image");
                                break;
                            case "checkbox":
                                targetElement = colCollection[c].ReturnInputElementByTypeAttribute(strElementType);
                                break;
                            case "radio":
                                targetElement = colCollection[c].ReturnInputElementByTypeAttribute(strElementType);
                                break;
                            case "select":
                                targetElement = colCollection[c].FindElement(By.TagName("Select"));
                                break;
                            default:
                                strRes = "Could not find the Element Type: " + strElementType + " in the table. ";
                                return null;
                        }
                        if (targetElement == null)
                        {
                            strRes = "Could not find the Element Type: " + strElementType + " in the table. ";
                            return null;
                        }

                        strRes = "Success";
                        return targetElement;
                    }

                }

                strRes = "Could not Locate the element using the search text : " + strSearchString + " in the table. ";
                return null;
            }
            catch (Exception e)
            {
                strRes = "Exception: " + e.Message;
                Assert.Fail(e.ToString());
                return null;
            }

        }

        public static IWebElement LocateElementInWebTableByTagAttribute(this IWebElement webTable, string xRowIdentifier,
        string strSearchString, string strAttributeAndValue, string strElementType, out string strRes)
        {
            try
            {

                ReadOnlyCollection<IWebElement> rowCollection = webTable.FindElements(By.XPath(".//" + xRowIdentifier));
                IWebElement targetRowElement = null;

                for (int i = 0; i < rowCollection.Count; i++)
                {
                    string textRowData = rowCollection[i].Text.ToLower();

                    if (textRowData.Contains(strSearchString.ToLower()))
                    {
                        targetRowElement = rowCollection[i];
                        break;
                    }

                }
                if (targetRowElement == null)
                {
                    strRes = "Could not find the text:" + strSearchString + " in the table. ";
                    return null;
                }

                ReadOnlyCollection<IWebElement> elementCollection =
                    targetRowElement.FindElements(By.TagName(strElementType));
                string[] arrAttributeAndValue = strAttributeAndValue.Split('=');
                string strAttribute = arrAttributeAndValue[0];
                string strAttributeValue = arrAttributeAndValue[1];

                foreach (var element in elementCollection)
                {
                    if (element.GetAttribute(strAttribute).ToLower().Contains(strAttributeValue.ToLower()))
                    {
                        strRes = "Success";
                        return element;
                    }
                }

                strRes = "Unable to find an element with " + strAttributeAndValue;
                return null;
            }
            catch (Exception e)
            {
                strRes = "Exception: " + e.Message;
                Assert.Fail(e.ToString());
                return null;
            }

        }

        public static IWebElement ReturnInputElementByTypeAttribute(this IWebElement actualElement, string strType)
        {
            ReadOnlyCollection<IWebElement> elementCollection = actualElement.FindElements(By.TagName("Input"));
            foreach (IWebElement element in elementCollection)
            {
                if (element.GetAttribute("type") == strType.ToLower())
                    return element;
            }
            return null;
        }

        public static DataTable GetWebTableData(this IWebElement webTable)
        {
            DataTable table = new DataTable();
            int iEmpty = 0;
            // Fetch the columns from a particuler row
            List<IWebElement> lstHeader = new List<IWebElement>(webTable.FindElements(By.TagName("th")));
            if (lstHeader.Count > 0)
            {
                // Traverse each column
                foreach (var elemTd in lstHeader)
                {
                    if (String.IsNullOrWhiteSpace(elemTd.Text))
                    {
                        table.Columns.Add("EmptyColumn" + iEmpty, typeof(string));
                        iEmpty = iEmpty + 1; // increment columne value
                    }
                    else
                    {
                        table.Columns.Add(elemTd.Text, typeof(string));
                    }
                }
            }
            // Fetch the columns from a particuler row
            List<IWebElement> lstRows = new List<IWebElement>(webTable.FindElements(By.TagName("tr")));
            if (lstRows.Count > 0)
            {
                // Traverse each column
                foreach (var row in lstRows)
                {
                    DataRow tempRow = table.NewRow();
                    List<IWebElement> lstCells = new List<IWebElement>(row.FindElements(By.TagName("td")));
                    if (lstCells.Count > 0)
                    {
                        for (int i = 0; i < lstCells.Count; i++)
                        {
                            tempRow[i] = lstCells[i].Text;
                        }
                        table.Rows.Add(tempRow);
                    }
                }
                return table;
            }
            else
            {
                return null;
            }
        }
    }
}