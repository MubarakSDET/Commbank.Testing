﻿using System.Collections.Generic;
using System.Linq;

namespace CommBank.Testing.Selenium.Infrastructure.Extensions
{
    internal static class InExtensions
    {
        public static bool In<T>(this T value, IEnumerable<T> list) => list.ToList().Contains(value);
        public static bool In<T>(this IEnumerable<T> list, T value) => list.Contains(value);

        public static bool In(this string[] arr, string value) => arr.Contains(value);

        public static bool In(this object[] obj, object value) => obj.Contains(value);

        public static bool In(this Dictionary<object, object> obj, object value) => obj.Keys.Contains(value);

        public static bool In(this Dictionary<string, List<string>> obj, string value) => obj.Keys.Contains(value);
        public static bool In(this IReadOnlyDictionary<string, List<string>> obj, string value) => obj.Keys.Contains(value);
    }
}