﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace CommBank.Testing.Selenium.Infrastructure.Extensions
{
    public static class StringExtensions
    {
        private static readonly TimeSpan DefaultWait = TimeSpan.FromSeconds(30);

        public static string RemoveInvalidFileNameCharacters(this string fileName)
        {
            Path.GetInvalidFileNameChars()
                .ToList()
                .ForEach(invalidChar => fileName = fileName.Replace(new string(new[] { invalidChar }), ""));

            return fileName;
        }

        public static bool WaitForElementToBecomeVisibleByCssSelector(this string cssSelector) => WaitForElementToBecomeVisibleByCssSelector(cssSelector, DefaultWait);

        public static bool WaitForElementToBecomeVisibleByCssSelector(this string cssSelector, TimeSpan defaultWait)
        {
            try
            {
                new WebDriverWait(WebDriverServiceLocator.Driver, defaultWait)
                    .Until(ExpectedConditions.ElementIsVisible(
                        By.CssSelector(cssSelector)));

                return true;
            }
            catch (WebDriverTimeoutException)
            {
            }

            return false;
        }

        public static string GetUntilOrEmpty(this string text, string stopAt = "_")
        {
            string returnText = "";
            if (!string.IsNullOrWhiteSpace(text))
            {
                int charLocation = text.IndexOf(stopAt, StringComparison.Ordinal);
                if (charLocation > 0)
                {
                    returnText = text.Substring(0, charLocation);
                }
            }
            return returnText;
        }
    }
}