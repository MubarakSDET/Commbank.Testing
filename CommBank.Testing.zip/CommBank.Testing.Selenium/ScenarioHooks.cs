using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using Allure.Commons;
using BoDi;
using CommBank.Testing.Extensions;
using CommBank.Testing.Selenium.Infrastructure.Extensions;
using CommBank.Testing.Selenium.Services;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Extensions;
using TechTalk.SpecFlow;

namespace CommBank.Testing.Selenium
{
    [Binding]
    public class ScenarioHooks
    {
        public static bool CaptureScreenShot = true;
        private static Assembly Assembly => typeof(ScenarioHooks).Assembly;

        private readonly IObjectContainer _objectContainer;

        private readonly ScenarioContext scenarioContext;

        [AfterScenario(Order = int.MinValue), Scope(Tag = "Transform_ScenarioOutline_Into_UniqueTests")]
        public void Transform_ScenarioOutline_Into_UniqueTests_AfterTestRun() => MakeScenarioOutlineIntoUniqueTests();

        private static readonly Dictionary<string, int> TestIterationCounter = new Dictionary<string, int>();

        public ScenarioHooks(IObjectContainer objectContainer, ScenarioContext scenarioContext)
        {
            this.scenarioContext = scenarioContext;
            this._objectContainer = objectContainer ?? throw new ArgumentNullException(nameof(scenarioContext));
        }

        private void MakeScenarioOutlineIntoUniqueTests()
        {
            scenarioContext.TryGetValue(out TestResult result);
            var paramsMatch = Regex.Match(TestContext.CurrentContext.Test.FullName, @"\((.*)\)$");

            if (paramsMatch.Success)
            {
                AllureLifecycle.Instance.UpdateTestCase(result.uuid, tc =>
                {
                    tc.name = TestContext.CurrentContext.Test.Name; //In order to have different tests in report
                    tc.historyId = TestContext.CurrentContext.Test.FullName; // or    Guid.NewGuid().ToString()
                });
            }
        }

        private static void UpdateTestCase(TestResult tc)
        {
            tc.name = $"{Guid.NewGuid().ToString()}";
            tc.historyId = Guid.NewGuid().ToString();
        }

        [AfterFeature]
        public static void AfterFeature() => CleanUpDriverFromContext(FeatureContext.Current);

        [AfterScenario]
        public void AfterScenario()
        {
            if (WebDriverServiceLocator.GlobalDriver == null) return;

            WebDriverServiceLocator.GlobalDriver.Dispose();
            WebDriverServiceLocator.GlobalDriver = null;
            CleanUpDriverFromContext(ScenarioContext.Current);
            cleanUpBrowserDriver();
        }

        public void cleanUpBrowserDriver()
        {
            //call taskkill / F / IM chromedriver.exe / T
            //call taskkill / F / IM IEDriverServer.exe / T

            Process[] chromeDriverProcesses = Process.GetProcessesByName("chromedriver");
            Process[] ieDriverProcesses = Process.GetProcessesByName("IEDriverServer");
            foreach (var chromeDriverProcess in chromeDriverProcesses)
            {
                chromeDriverProcess.Kill();
            }
            foreach (var ieDriverProcess in ieDriverProcesses)
            {
                ieDriverProcess.Kill();
            }
        }

        [AfterScenarioBlock]
        public void AfterScenarioBlock()
        {
        }

        [AfterStep]
        public void AfterStep()
        {
            if (CaptureScreenShot)
                TakeScreenShot();
        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            if (WebDriverServiceLocator.GlobalDriver == null) return;

            WebDriverServiceLocator.GlobalDriver.Dispose();
            WebDriverServiceLocator.GlobalDriver = null;
        }

        [BeforeFeature, Scope(Tag = "LoadCsvData")]
        public static void BeforeFeature()
        {
            var csvPath = Path.Combine(".\\TestData\\",FeatureContext.Current.FeatureInfo.Title + ".csv");
            if (!File.Exists(csvPath))
            {
                Assert.Fail("Unable to find the Test Data File @ " + csvPath);
            }
            DataService.LoadDataFromCsvToFeatureContext(csvPath,"TestCase");
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
        }

        [BeforeScenarioBlock]
        public void BeforeScenarioBlock()
        {
        }

        [BeforeStep]
        public void BeforeStep()
        {
        }
        /*
        //Order of specflow default events
        [BeforeTestRun]
          [BeforeFeature] -- need driver instance here for Login Once
            [BeforeScenario] -- browser initialization for multi browser testing
              [BeforeScenarioBlock]
                [BeforeStep]
                [AfterStep]
              [AfterScenarioBlock]
            [AfterScenario]
          [AfterFeature]
        [AfterTestRun]
         * */

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            Directory.CreateDirectory(Assembly.GetArtifactsFolder());
        }

        private static void CleanUpDriverFromContext(SpecFlowContext context)
        {
            if (!context.ContainsKey("Driver")) return;

            var driver = (IWebDriver) context["Driver"];
            driver.Dispose();

            context.Remove("Driver");
        }

        private static void TakeScreenShot()
        {
            bool val = false;
            Thread.Sleep(150);
            if (!WebDriverServiceLocator.DriverIsAvailable) return;
            val = Infrastructure.Extensions.WebDriverExtensions.isAlertPresent(WebDriverServiceLocator.Driver);
            if (val)
            {
                return;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(WebDriverServiceLocator.Driver.Title)) return;
                var screenShot = WebDriverServiceLocator.Driver.TakeScreenshot();
                var screenShotFileName = ScenarioContext.Current.ToScreenShotFileName();
                AllureLifecycle.Instance.AddAttachment(screenShotFileName.Name, "Image", screenShot.AsByteArray);
                Trace.WriteLine($"ScreenShot path: {screenShotFileName}");
                screenShot.SaveAsFile(screenShotFileName.FullName, ScreenshotImageFormat.Jpeg);
            }
            //if (string.IsNullOrWhiteSpace(WebDriverServiceLocator.Driver.Title)) return;
            //var screenShot = WebDriverServiceLocator.Driver.TakeScreenshot();
            //var screenShotFileName = ScenarioContext.Current.ToScreenShotFileName();
            //AllureLifecycle.Instance.AddAttachment(screenShotFileName.Name, "Image", screenShot.AsByteArray);
            //Trace.WriteLine($"ScreenShot path: {screenShotFileName}");
            //screenShot.SaveAsFile(screenShotFileName.FullName, ScreenshotImageFormat.Jpeg);
        }
    }
}