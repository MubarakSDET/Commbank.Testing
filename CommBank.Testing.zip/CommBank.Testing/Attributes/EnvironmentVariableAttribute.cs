﻿using System;

namespace CommBank.Testing.Attributes
{
    public class EnvironmentVariableAttribute : Attribute
    {
    }
}