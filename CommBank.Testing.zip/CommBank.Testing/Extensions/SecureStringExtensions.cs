﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security;

namespace CommBank.Testing.Extensions
{
    [DebuggerStepThrough]
    public static class SecureStringExtensions
    {
        public static string ConvertToUnsecureString(this SecureString securePassword)
        {
            if (securePassword == null) throw new ArgumentNullException(nameof(securePassword));

            var unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(securePassword);

                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        public static SecureString ToSecureString(this string stringToSecure) => stringToSecure?.ToCharArray().ToSecureString();

        public static SecureString ToSecureString(this char[] str)
        {
            var secureString = new SecureString();
            Array.ForEach(str, secureString.AppendChar);

            return secureString;
        }
    }
}