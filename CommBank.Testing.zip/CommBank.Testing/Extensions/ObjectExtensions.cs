﻿using System.Collections.Generic;

namespace CommBank.Testing.Extensions
{
    public static class ObjectExtensions
    {
        public static List<T> AsList<T>(this T theObject) => new List<T> {theObject};
    }
}