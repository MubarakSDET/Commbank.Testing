﻿using System.IO;
using System.Linq;
using CommBank.Testing.Encryption;

namespace CommBank.Testing.Extensions
{
    public static class EncryptionExtensions
    {
        public static void DecryptFiles(this DirectoryInfo processingDirectory, IPgpEncryptionService pgpEncryptionService, SearchOption searchOption = SearchOption.AllDirectories) =>
            processingDirectory.GetFiles("*.gpg", searchOption)
                .AsParallel()
                .ToList()
                .ForEach(file => { pgpEncryptionService.DecryptFile(file, file.NameWithoutExtension()); });
    }
}