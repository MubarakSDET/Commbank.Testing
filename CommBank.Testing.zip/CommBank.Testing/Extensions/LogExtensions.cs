﻿using System;
using System.Diagnostics;

namespace CommBank.Testing.Extensions
{
    public static class LogExtensions
    {
        public static string Log(this string theMessage)
        {
            Debug.WriteLine(theMessage);
            Console.WriteLine(theMessage);

            return theMessage;
        }
    }
}