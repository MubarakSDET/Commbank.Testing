﻿using System;

namespace CommBank.Testing.Extensions
{
    public static class NumericExtensions
    {
        public static bool ToBool(this string theString, string trueValue = "Y", bool defaultValue = false) =>
            string.IsNullOrWhiteSpace(theString)
                ? defaultValue
                : theString.Equals(trueValue, StringComparison.InvariantCultureIgnoreCase);
    }
}