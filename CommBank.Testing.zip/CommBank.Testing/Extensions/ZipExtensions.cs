﻿using System.IO;
using System.IO.Compression;
using System.Linq;

namespace CommBank.Testing.Extensions
{
    public static class ZipExtensions
    {
        public static void ExtractFiles(this DirectoryInfo processingDirectory, SearchOption searchOption = SearchOption.TopDirectoryOnly) =>
            processingDirectory.GetFiles("*.zip", searchOption)
                .AsParallel()
                .ToList()
                .ForEach(file =>
                {
                    var fileName = file.Name.Replace(file.Extension, string.Empty);
                    var destinationDirectoryName = Path.Combine(file.DirectoryName, fileName);

                    var directoryInfo = new DirectoryInfo(destinationDirectoryName);
                    if (directoryInfo.Exists) directoryInfo.Delete(true);

                    ZipFile.ExtractToDirectory(file.FullName, destinationDirectoryName);
                });
    }
}