﻿using System;
using System.Linq;
using Autofac;
using Autofac.Core.Lifetime;

namespace CommBank.Testing.Extensions
{
    public static class ContainerExtensions
    {
        public static ContainerBuilder CopyContainer(this IContainer source,
            Action<ContainerBuilder> newRegistrations,
            params Type[] typesToExclude)
        {
            var containerBuilder = new ContainerBuilder();
            source.ComponentRegistry.Registrations
                .Where(cr => cr.Activator.LimitType != typeof(LifetimeScope))
                .Where(cr => typesToExclude.All(t => t.FullName != cr.Activator.LimitType.FullName))
                .ToList()
                .ForEach(cr => containerBuilder.RegisterComponent(cr));

            source.ComponentRegistry.Sources
                .ToList()
                .ForEach(rs => containerBuilder.RegisterSource(rs));

            newRegistrations.Invoke(containerBuilder);

            return containerBuilder;
        }
    }
}