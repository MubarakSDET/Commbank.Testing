﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommBank.Testing.Extensions
{
    public static class StringExtensions
    {
        public static string ConvertDateFormat(string txtDate)
        {
            string formattedDate = "";
            var parsedDate = DateTime.ParseExact(txtDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            formattedDate = parsedDate.ToString("dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            return formattedDate;
        }

        public static string StatesInAustralia(string key)
        {
            Dictionary<string, string> allStates = new Dictionary<string, string>();
            allStates.Add("NSW", "New South Wales");
            allStates.Add("QLD", "Queensland");
            allStates.Add("SA", "South Australia");
            allStates.Add("TAS", "Tasmania");
            allStates.Add("VIC", "Victoria");
            allStates.Add("WA", "Western Australia");
            allStates.Add("ACT", "Australian Capital Territory");
            allStates.Add("NT", "Northern Territory");
            return allStates[key];
        }
    }
}