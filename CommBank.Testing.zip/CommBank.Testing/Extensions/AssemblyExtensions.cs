﻿using System;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO.Abstractions;
using System.Reflection;

namespace CommBank.Testing.Extensions
{
    public static class AssemblyExtensions
    {
        private static readonly IFileSystem FileSystem = new FileSystem();

        public static string GetArtifactsFile(this Assembly executingAssembly, string relativeFileName) => FileSystem.Path.Combine(GetArtifactsFolder(executingAssembly), relativeFileName);

        public static string GetArtifactsFolder(this Assembly executingAssembly, string folderName = ".build")
        {
            var testArtifactsFolder = FileSystem.Path.Combine(executingAssembly.GetRepositoryRootFolder(), folderName);
            FileSystem.Directory.CreateDirectory(testArtifactsFolder);
            return testArtifactsFolder;
        }

        public static string GetLocation(this Assembly executingAssembly)
        {
            executingAssembly = executingAssembly ?? Assembly.GetExecutingAssembly();

            var codeBase = executingAssembly.CodeBase;
            var uri = new UriBuilder(codeBase);
            var path = Uri.UnescapeDataString(uri.Path);
            var location = FileSystem.Path.GetDirectoryName(path);

            var message = $@"{executingAssembly.FullName}'s location is '{location}')";
            Console.WriteLine(message);

            return location;
        }

        public static string GetReportsFolder(this Assembly executingAssembly, string folderName = "allure-reports")
        {
            var testArtifactsFolder = FileSystem.Path.Combine(GetArtifactsFolder(executingAssembly), folderName);
            FileSystem.Directory.CreateDirectory(testArtifactsFolder);
            return testArtifactsFolder; 
        }

        public static string GetAllurePath(this Assembly executingAssembly)
        {
            string allureFolder = null;
            try
            {
                allureFolder = ConfigurationManager.AppSettings.Get("Allure.Path");
            }
            catch (Exception)
            {
            }

            if (allureFolder == null)
            {
                allureFolder = "allure\\Current\\bin";
            }
            var testArtifactsFolder = FileSystem.Path.Combine(executingAssembly.GetLocation(), allureFolder);
            
            return testArtifactsFolder;
        }

        [SuppressMessage("ReSharper", "PossibleNullReferenceException")]
        public static string GetRepositoryRootFolder(this Assembly executingAssembly)
        {
            var location = executingAssembly.GetLocation();

            string updatedLocation = null;
            if (FileSystem.DirectoryInfo.FromDirectoryName(location).Parent.Name.Equals("bin", StringComparison.InvariantCultureIgnoreCase))
                updatedLocation = FileSystem.DirectoryInfo.FromDirectoryName(location).Parent.Parent.Parent.Parent.FullName;

            if (FileSystem.DirectoryInfo.FromDirectoryName(location).Parent.Parent.Name.Equals("bin", StringComparison.InvariantCultureIgnoreCase))
                updatedLocation = FileSystem.DirectoryInfo.FromDirectoryName(location).Parent.Parent.Parent.Parent.Parent.FullName;

            return updatedLocation ?? FileSystem.DirectoryInfo.FromDirectoryName(location).FullName;
        }

        [SuppressMessage("ReSharper", "PossibleNullReferenceException")]
        public static string GetSolutionFolder(this Assembly executingAssembly) => FileSystem.Path.Combine(GetRepositoryRootFolder(executingAssembly), "src");

        public static string GetTestDataFile(this Assembly executingAssembly, string relativeFileName) =>
            FileSystem.Path.Combine(GetTestDataFolder(executingAssembly), relativeFileName);

        public static string GetTestDataFolder(this Assembly executingAssembly, string folderName = "TestData")
        {
            var folder = FileSystem.Path.Combine(executingAssembly.GetLocation(), folderName);
            FileSystem.Directory.CreateDirectory(folder);
            Console.WriteLine($"GetTestDataFolder-'{folder}'");

            return folder;
        }

        public static string GetWorkingFile(this Assembly executingAssembly, string fileName) => FileSystem.Path.Combine(GetWorkingFilesFolder(executingAssembly), fileName);

        public static string GetWorkingFilesFolder(this Assembly executingAssembly)
        {
            var assembly = executingAssembly ?? typeof(AssemblyExtensions).Assembly;
            var path = FileSystem.Path.Combine(assembly.GetRepositoryRootFolder(), "WorkingFiles");

            return FileSystem.DirectoryInfo.FromDirectoryName(path).FullName;
        }
    }
}