﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace CommBank.Testing.Extensions
{
    public static class DataTableExtensions
    {
        public static DataRow[] FilterRows(this DataTable dataTable, string ColumnName, string Value)
        {
            var filteredRows = dataTable.Select(ColumnName + " LIKE '%" + Value + "%'");
            return filteredRows;
        }
    }
}
