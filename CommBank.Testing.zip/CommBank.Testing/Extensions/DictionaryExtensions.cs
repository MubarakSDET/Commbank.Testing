﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CommBank.Testing.Extensions
{
    public static class DictionaryExtensions
    {
        public static IDictionary<string, string> ToDictionary(this IDictionary dictionary) =>
            dictionary.Keys.Cast<object>().ToDictionary(k => k.ToString(), v => dictionary[v].ToString(), StringComparer.InvariantCultureIgnoreCase);
    }
}