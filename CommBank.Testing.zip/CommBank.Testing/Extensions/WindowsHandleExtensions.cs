﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using CommBank.Testing.Helpers;

namespace CommBank.Testing.Extensions
{
    public static class WindowsHandleExtensions
    {
        public static void CloseWindow(this IEnumerable<IntPtr> theHandles) =>
            theHandles?.ToList().ForEach(CloseWindow);

        public static void CloseWindow(this IntPtr theHandle)
        {
            if (theHandle.ToInt32() <= 0) return;

            WindowHandleFunctions.CloseWindow(theHandle);
        }

        public static IEnumerable<IntPtr> FindWindowsWithThisText(this string theText) => Process.GetProcesses()
            .Where(x => x.MainWindowTitle.Equals($"{theText}", StringComparison.InvariantCultureIgnoreCase))
            .Select(x => x.MainWindowHandle)
            .ToList();
    }
}