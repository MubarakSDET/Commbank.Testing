﻿using System.IO;
using System.Security;

namespace CommBank.Testing.Encryption
{
    public interface IPgpEncryptionConfig
    {
        SecureString PassPhrase { get; }
        FileInfo PrivateKeyFileInfo { get; }
        FileInfo PublicKeyFileInfo { get; }
    }
}