﻿using System.IO;
using CommBank.Testing.Extensions;
using PgpCore;

namespace CommBank.Testing.Encryption
{
    public class PgpEncryptionService : IPgpEncryptionService
    {
        private readonly IPgpEncryptionConfig _config;

        public PgpEncryptionService(IPgpEncryptionConfig config) => _config = config;

        public void EncryptFile(FileInfo sourceFileInfo, FileInfo outputFileInfo)
        {
            outputFileInfo?.Directory?.Create();

            using (var pgp = new PGP())
            {
                pgp.EncryptFile(
                    sourceFileInfo.FullName,
                    outputFileInfo?.FullName,
                    _config.PublicKeyFileInfo.FullName);
            }
        }

        public void DecryptFile(FileInfo sourceFileInfo, FileInfo outputFileInfo)
        {
            outputFileInfo?.Directory?.Create();

            using (var pgp = new PGP())
            {
                pgp.DecryptFile(
                    sourceFileInfo.FullName,
                    outputFileInfo?.FullName,
                    _config.PrivateKeyFileInfo.FullName,
                    _config.PassPhrase.ConvertToUnsecureString());
            }
        }
    }

    public interface IPgpEncryptionService
    {
        void DecryptFile(FileInfo sourceFileInfo, FileInfo outputFileInfo);
        void EncryptFile(FileInfo sourceFileInfo, FileInfo outputFileInfo);
    }
}