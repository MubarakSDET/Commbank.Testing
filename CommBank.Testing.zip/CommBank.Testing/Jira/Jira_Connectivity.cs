﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using NUnit.Framework;
using SecureConnect;
using RestSharp;


namespace CFS.UI.Auto.FirstNet.Core.Framework
{
    public class Jira_Connectivity
    {

        /// <summary>
        /// This function will encode the authorisation using UTF8Encoding 
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="encrypted_pwd"></param>
        /// <returns></returns>
        private static string HeaderAuthorisation(string userid, string encrypted_pwd)
        {
            try
            {
                string decrypt_pwd = Password.Decrypt(encrypted_pwd, "au-" + userid);
                string mergedCredentials = string.Format("{0}:{1}", userid, decrypt_pwd);
                byte[] byteCredentials = UTF8Encoding.UTF8.GetBytes(mergedCredentials);
                return Convert.ToBase64String(byteCredentials);
            }
            catch (Exception e)
            {
                Assert.Fail("Exception :" + e);
                return null;
            }
        }

        /// <summary>
        /// This function is to update the Test case status to Pass or Fail and attach the test results for failed case
        /// </summary>
        /// <param name="tc_status"></param>
        /// <param name="TestRun_ID"></param>
        /// <param name="TestCase_ID"></param>
        /// <param name="attachment_file"></param>
        /// <param name="post_method"></param>
        /// Example: Jira_Connectivity.UpdateTC("FAIL", "WDC-R1", "WDC-T12", KeyFunctions.CurrentTestCaseResultPath, "POST");
        public static void UpdateTC(string tc_status, string TestRun_ID, string TestCase_ID, string attachment_file, string post_method = "PUT") //Configure the Configfile for UserId and EncryptedPassword
        {
            string jsonSchema_UpdateTc;
            string TC_Update_URL;
            string TR_Attachment_URL = null;
            string userid; string encrypted_pwd;

            if (tc_status.ToUpper().Equals("PASS"))
            {
                jsonSchema_UpdateTc = @"{""status"": ""Pass"",
                                                          ""comment"": ""Automation"",
                                                          ""scriptResults"": [
                                                            {
                                                              ""index"": 0,
                                                              ""status"": ""Pass"",
                                                              ""comment"": ""Automation""
                                                            }
                                                          ]
                                                 }";
            }
            else
            {
                jsonSchema_UpdateTc = @"{""status"": ""Fail"",
                                                              ""comment"": ""fail"",
                                                               ""scriptResults"": [
                                                                {
                                                                  ""index"": 0,
                                                                  ""status"": ""Fail"",
                                                                  ""comment"": ""Automation""
                                                                }
                                                              ]
                                                }";
            }

            TC_Update_URL = @"https://jira.internal.cba/rest/atm/1.0/testrun/" + TestRun_ID + "/testcase/" + TestCase_ID + "/testresult";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(TC_Update_URL);
            request.Method = post_method.ToUpper();
            request.ContentType = "application/json";
            request.ContentLength = jsonSchema_UpdateTc.Length;

            userid = TestContext.Parameters.Get("LAN.UserName", KeyFunctions.GetConfigData("LAN.UserName"));
            encrypted_pwd = TestContext.Parameters.Get("Jira.EncPassword", KeyFunctions.GetConfigData("Jira.EncPassword"));

            string base64Credentials = HeaderAuthorisation(userid, encrypted_pwd);
            request.Headers.Add("Authorization", "Basic " + base64Credentials);

            using (Stream webStream = request.GetRequestStream())
            using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
            {
                requestWriter.Write(jsonSchema_UpdateTc);
            }

            try
            {
                WebResponse webResponse = request.GetResponse();
                using (Stream webStream = webResponse.GetResponseStream())
                {
                    if (webStream != null)
                    {
                        using (StreamReader responseReader = new StreamReader(webStream))
                        {
                            string response = responseReader.ReadToEnd();
                            string[] arr_TestResultID = response.Split(new string[] { ":" }, StringSplitOptions.None);
                            string TestResultId = arr_TestResultID[1].Replace("}", "");
                            if (tc_status.ToUpper().Equals("FAIL"))
                            {
                                TR_Attachment_URL = @"https://jira.internal.cba/rest/atm/1.0/testresult/" + TestResultId + "/attachment";
                                Jira_Connectivity.attachTc(base64Credentials, attachment_file, TR_Attachment_URL);

                                if(TestContext.Parameters.Get("Jira.AutoBugRaise", KeyFunctions.GetConfigData("Jira.AutoBugRaise") == "Yes"))
                                    Jira_Connectivity.RaiseBug(tc_status, TestRun_ID, TestCase_ID, attachment_file, "POST");
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Exception :" + e);
            }
        }


        /// <summary>
        /// This function is to attach the test results for failed case
        /// </summary>
        /// <param name="base64Credentials"></param>
        /// <param name="filename_path"></param>
        /// <param name="TR_Attachment_URL"></param>
        private static void attachTc(string base64Credentials, string filename_path, string TR_Attachment_URL)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                MultipartFormDataContent form = new MultipartFormDataContent();
                httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + base64Credentials);
                if (TR_Attachment_URL.Contains("issue"))
                    httpClient.DefaultRequestHeaders.Add("X-Atlassian-Token", "nocheck");
                string path = filename_path + "\\Screenshots";
                if (!Directory.Exists(path))
                {
                    string[] htmlFiles = Directory.GetFiles(filename_path, "*.html")
                                      .Select(Path.GetFileName)
                                      .ToArray();
                    filename_path = filename_path + "\\" + htmlFiles[0];
                }
                else
                {
                    string pattern = "*.png";
                    var dirInfo = new DirectoryInfo(path);
                    var file = (from f in dirInfo.GetFiles(pattern) orderby f.LastWriteTime descending select f).First();
                    filename_path = file.FullName;
                }
                FileStream fs = File.OpenRead(filename_path);
                var streamContent = new StreamContent(fs);
                form.Add(streamContent, "file", Path.GetFileName(filename_path));
                var message = httpClient.PostAsync(TR_Attachment_URL, form).Result;
            }

            catch (Exception e)
            {
                Assert.Fail("Exception :" + e);
            }

        }

        public static void RaiseBug(string tc_status, string TestRun_ID, string TestCase_ID, string attachment_file, string post_method = "PUT") //Configure the Configfile for UserId and EncryptedPassword
        {
            string jsonSchema_RaiseBug;
            string RaiseBug_URL;
            string Bug_Attachment_URL = null;
            string BugId = null;
            string jsonSchema_linkDefect;
            Dictionary<string, string> testCase = new Dictionary<string, string>();
            string userid = KeyFunctions.GetConfigData("LAN.UserName");
            string encrypted_pwd = KeyFunctions.GetConfigData("Jira.EncPassword");

            //Get TestCase Details
            string testDetails_URL = @"https://jira.internal.cba/rest/atm/1.0/testcase/" + TestCase_ID;
            HttpWebRequest testrequest = (HttpWebRequest)WebRequest.Create(testDetails_URL);
            string base64Credentials = HeaderAuthorisation(userid, encrypted_pwd);
            testrequest.Headers.Add("Authorization", "Basic " + base64Credentials);

            try
            {
                WebResponse response = testrequest.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    string getresponse = reader.ReadToEnd();
                    getresponse = getresponse.Replace("{", "").Replace("}", "").Replace("\\", "").Replace("\"", "");
                    string[] arr_TestCase = getresponse.Split(new string[] { "," }, StringSplitOptions.None);
                    string[] arrTemp;
                    for (int i = 0; i < arr_TestCase.Length; i++)
                    {
                        arrTemp = arr_TestCase[i].Split(':');
                        if (arrTemp[0].Equals("testScript"))
                            testCase.Add(arrTemp[0], arrTemp[2]);
                        else
                            testCase.Add(arrTemp[0], arrTemp[1]);
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }

            //Raise Bug
            string key = testCase["projectKey"];
            string assignee = KeyFunctions.GetConfigData("LAN.UserName");
            string priority = "Medium";
            string bugType = "Functional";
            string summary = testCase["objective"];
            string description = NUnit.Framework.TestContext.CurrentContext.Test.Name;
            string acceptanceCriteria = testCase["testScript"].Replace("<br />", ", ");
            string environment = KeyFunctions.GetConfigData("Environment");
            string testLevel = "";
            if (environment.Equals("Staging"))
                testLevel = environment;
            else
                testLevel = "UAT";

            jsonSchema_RaiseBug = @"{{""fields"": 
                                        {{
                                            ""project"":
                                            {{ 
                                                ""key"": ""{0}""
                                            }},
                                            ""issuetype"": 
                                            {{
                                                ""name"": ""Bug""
                                            }},
                                            ""assignee"":
                                            {{
                                                ""name"": ""{1}""
                                            }},
                                            ""priority"":
                                            {{
                                                ""name"": ""{2}""
                                            }},                                            
                                            ""customfield_11801"":
                                            {{ 
                                               ""value"": ""{3}""
                                            }},
                                            ""customfield_11800"":
                                            {{ 
                                               ""value"": ""{4}""
                                            }},
                                            ""labels"":
                                            [  
                                               ""Automation""
                                            ],
                                            ""summary"": ""{5}"",
                                            ""description"": ""{6}"",
                                            ""customfield_11500"": ""{7}"",
                                            ""environment"": ""{8}""
                                        }}
                                    }}";

            jsonSchema_RaiseBug = string.Format(jsonSchema_RaiseBug, key, assignee, priority, bugType, testLevel, summary, description, acceptanceCriteria, environment);
            RaiseBug_URL = @"https://jira.internal.cba/rest/api/latest/issue/";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(RaiseBug_URL);
            request.Method = post_method.ToUpper();
            request.ContentType = "application/json";
            request.ContentLength = jsonSchema_RaiseBug.Length;
            request.Headers.Add("Authorization", "Basic " + base64Credentials);
            using (Stream webStream = request.GetRequestStream())
            using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
            {
                requestWriter.Write(jsonSchema_RaiseBug);
            }
            try
            {
                WebResponse webResponse = request.GetResponse();
                using (Stream webStream = webResponse.GetResponseStream())
                {
                    if (webStream != null)
                    {
                        using (StreamReader responseReader = new StreamReader(webStream))
                        {
                            string response = responseReader.ReadToEnd();
                            string[] arr_BugID = response.Split(new string[] { ":" }, StringSplitOptions.None);
                            arr_BugID = arr_BugID[2].Replace("}", "").Replace("\"", "").Split(',');
                            BugId = arr_BugID[0];
                            Bug_Attachment_URL = @"https://jira.internal.cba/rest/api/latest/issue/" + BugId + "/attachments";
                            Jira_Connectivity.attachTc(base64Credentials, attachment_file, Bug_Attachment_URL);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Exception :" + e);
            }

            //Link bug to testcase
            testDetails_URL = @"https://jira.internal.cba/rest/atm/1.0/testcase/" + TestCase_ID;
            HttpWebRequest linkRequest = (HttpWebRequest)WebRequest.Create(testDetails_URL);
            base64Credentials = HeaderAuthorisation(userid, encrypted_pwd);
            linkRequest.Headers.Add("Authorization", "Basic " + base64Credentials);
            jsonSchema_linkDefect = @"{{""issueLinks"":[""{0}""]}}";
            jsonSchema_linkDefect = string.Format(jsonSchema_linkDefect, BugId);
            linkRequest.Method = "PUT";
            linkRequest.ContentType = "application/json";
            linkRequest.ContentLength = jsonSchema_linkDefect.Length;
            using (Stream linkwebStream = linkRequest.GetRequestStream())
            using (StreamWriter linkrequestWriter = new StreamWriter(linkwebStream, System.Text.Encoding.ASCII))
            {
                linkrequestWriter.Write(jsonSchema_linkDefect);
            }
        }
    }
}