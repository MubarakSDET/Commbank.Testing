﻿using System.IO;

namespace CommBank.Testing.FileIO
{
    public class FileService
    {
        public static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            var dir = new DirectoryInfo(sourceDirName);

            if (!dir.Exists) throw new DirectoryNotFoundException($"Source directory does not exist or could not be found: {sourceDirName}");

            var dirs = dir.GetDirectories();
            if (!Directory.Exists(destDirName)) Directory.CreateDirectory(destDirName);

            var files = dir.GetFiles();
            foreach (var file in files) file.CopyTo(Path.Combine(destDirName, file.Name), false);

            if (!copySubDirs) return;

            foreach (var subdir in dirs) DirectoryCopy(subdir.FullName, Path.Combine(destDirName, subdir.Name), copySubDirs);
        }
    }
}