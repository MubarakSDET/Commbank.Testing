﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;

namespace CommBank.Testing.Serialization
{
    public class MultiFormatDateConverter : JsonConverter
    {
        public List<string> DateTimeFormats { get; set; } = new List<string> { "dd/MM/yyyy h:mm:ss tt", "dd/MM/yyyy" };

        public override bool CanConvert(Type objectType) => objectType == typeof(DateTime?) | objectType == typeof(DateTime);

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var dateString = (string)reader.Value;
            if (string.IsNullOrWhiteSpace(dateString)) return null;

            foreach (var format in DateTimeFormats)
            {
                if (DateTime.TryParseExact(dateString, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out var date))
                    return date;
            }
            throw new JsonException("Unable to parse \"" + dateString + "\" as a date.");
        }

        public override bool CanWrite => false;

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer) => throw new NotImplementedException();
    }
}