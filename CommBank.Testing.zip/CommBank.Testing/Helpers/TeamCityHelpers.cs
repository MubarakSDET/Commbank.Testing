﻿using System;

namespace CommBank.Testing.Helpers
{
    public static class TeamCityHelpers
    {
        public static bool IsOnTeamCity() => !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("TEAMCITY_VERSION"));
    }
}