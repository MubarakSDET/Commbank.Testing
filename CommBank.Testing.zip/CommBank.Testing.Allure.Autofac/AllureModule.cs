﻿using System.Reflection;
using Allure.SpecFlowPlugin;
using Autofac;
using Module = Autofac.Module;

// ReSharper disable UnusedMember.Global

namespace CommBank.Testing.Allure.Autofac
{
    public class AllureModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<AllureBindings>();
        }

        public static Assembly Assembly => typeof(AllureModule).Assembly;
    }
}
