﻿using System;
using System.IO;
using System.Reflection;
using System.Xml;
using CommBank.Testing.Extensions;
using CommBank.Testing.WebServices.Data;
using CommBank.Testing.WebServices.Utilities;

namespace CommBank.Testing.WebServices.Helper
{
    public class WebServiceHelper
    {
        public static void Create_IFW_Non_Person_Customers(string CSVPath)
        {
            DataSheet dt = new DataSheet { Path = CSVPath };
            int StartRow = 1;
            var Columns = dt.GetHeader();
            for (int CurrentRow = StartRow; CurrentRow < dt.RowCount; CurrentRow++)
            {
                String StatusCode, response = string.Empty;
                var CIF_ID = string.Empty;
                var row = dt.GetRowByIndex(CurrentRow);
                var type_of_customer = dt.GetColumnValue("entityType", CurrentRow);
                var CIFID = dt.GetColumnValue("CIFID", CurrentRow);
                if (CIFID == "")
                {
                    CreateNonPerson(type_of_customer, Columns, row, out StatusCode, out response);
                    if (StatusCode == "OK")
                    {
                        var CIF_ID_Array = ConstructRequest.GetData(response, "CIFIdentifier");
                        // Console.Write(CIF_ID_Array + Environment.NewLine);
                        if (CIF_ID_Array.Length > 0)
                        {
                            dt.SetColumnValue("CIFID", CurrentRow, CIF_ID_Array[0]);
                            CustomerIdentifyVerification(CIF_ID_Array[0], out StatusCode, out response);
                            if (StatusCode == "OK") { }

                        } else
                        {
                            dt.SetColumnValue("CIFID", CurrentRow, "Please see file : " + " C:\\temp\\" + CurrentRow + ".txt for error info." );
                            File.WriteAllText(@"C:\temp\" + CurrentRow + ".txt", response);
                        }
                    }
                }

                var Risk = dt.GetColumnValue("Risk_Profile", CurrentRow);
                if (Risk == "")
                {
                    var identifier = string.Empty;
                    var CRIS = string.Empty;
                    CIFID = dt.GetColumnValue("CIFID", CurrentRow);
                    WebServiceHelper.ReserveCrisCode(CIFID, out StatusCode, out identifier, out CRIS);
                    if (StatusCode == "OK")
                        dt.SetColumnValue("//*[@scheme='SAP']", CurrentRow, identifier);
                        dt.SetColumnValue("//*[@scheme='CRIS']", CurrentRow, CRIS);
                    row = dt.GetRowByIndex(CurrentRow);
                    CustomerRiskProfile(CIFID, Columns, row, out StatusCode, out response);
                    if (StatusCode == "OK")
                        SwapCrisCRP(CIFID, CRIS, out StatusCode, out response);
                    if (StatusCode == "OK")
                        dt.SetColumnValue("Risk_Profile", CurrentRow, "Done");
                }
                var RiskLinking = dt.GetColumnValue("Risk_Profile", CurrentRow);

            }
            
            
        }

        private static void CreateNonPerson(string type, string[] columns, string[] values, out string statuscode, out string response)
        {
            var _url = "https://es.test5.core.esb.cba/ifw470Dispatcher/InvolvedPartyManagement.asmx";
            var _action = "http://commbank.com.au/ifw/470/InvolvedPartyManagement/RecordInvolvedParty";
            var _path = Path.GetFullPath(@"./data/soap_services/" + type + ".xml");
            if (!File.Exists(_path))
                _path = Path.GetFullPath(@"./data/soap_services/RecordInvolvedParty_NP.xml");

            XmlDocument soapEnvelopeXml = ConstructRequest.UpdateAllField(_path, columns, values);
            CommBank.Testing.WebServices.Core.WebService.Post(_url, _action, soapEnvelopeXml, out statuscode, out response);
        }

        private static void CustomerIdentifyVerification(string CIFID, out string statuscode, out string response)
        {
            var _url = "https://es.test5.core.esb.cba/ifw470Dispatcher/InvolvedPartyManagement.asmx";
            var _action = "http://commbank.com.au/ifw/470/InvolvedPartyManagement/ModifyInvolvedParty";
            var _path = Path.GetFullPath(@"./data/soap_services/ModifyInvolvedParty.xml");


            XmlDocument soapEnvelopeXml = ConstructRequest.UpdateSingleField(_path, "CIFIdentifier", CIFID);
            CommBank.Testing.WebServices.Core.WebService.Post(_url, _action, soapEnvelopeXml, out statuscode, out response);
        }
        private static void CustomerRiskProfile(string CIFID, string[] columns, string[] values, out string statuscode, out string response)
        {
            var _url = "https://es.test5.core.esb.cba/ifw470Dispatcher/InvolvedPartyManagement.asmx";
            var _action = "http://commbank.com.au/ifw/470/InvolvedPartyManagement/ModifyInvolvedParty";
            var _path = Path.GetFullPath(@"./data/soap_services/ModifyInvolvedParty_CRIS.xml");


            XmlDocument soapEnvelopeXml = ConstructRequest.UpdateAllField(_path, columns,values);
            soapEnvelopeXml.Save(@"c:\temp\risk.xml");
            CommBank.Testing.WebServices.Core.WebService.Post(_url, _action, soapEnvelopeXml, out statuscode, out response);
        }
        public string  GetCustomerDetails(string CIFID, out string statuscode)
        {
            string response = string.Empty;
            var _url = "https://es.test2.core.esb.cba/ifw470Dispatcher/InvolvedPartyManagement.asmx";
            var _action = "http://commbank.com.au/ifw/470/InvolvedPartyManagement/RetrieveInvolvedParty";
            var _path = Path.GetFullPath(Assembly.GetExecutingAssembly().GetLocation() + @"./data/soap_services/RetrieveInvolvedParty.xml");

            XmlDocument soapEnvelopeXml = ConstructRequest.UpdateSingleField(_path, "CIFIdentifier", CIFID);
            Core.WebService.Post(_url, _action, soapEnvelopeXml, out statuscode, out response);

            return response;
        }

        public static void ReserveCrisCode(string CIFID, out string statuscode, out string identifier, out string criscode)
        {
            string response = string.Empty;
            var _url = "https://nd.t5.ep.test.cba:9944/InvolvedPartyGroup/V1/PS00";
            var _action = "http://ep.cba/core/services/enterprise/customerdatamanagement/involvedpartygroup/v1/create";
            var _path = Path.GetFullPath(@"./data/soap_services/InvolvePartyGroup.xml");


            XmlDocument soapEnvelopeXml = ConstructRequest.UpdateSingleField(_path, "CIFIdentifier", CIFID);
            CommBank.Testing.WebServices.Core.WebService.Post(_url, _action, soapEnvelopeXml, out statuscode, out response);

             identifier =  ConstructRequest.GetDataxpath(response, "//identifier");
             criscode = ConstructRequest.GetDataxpath(response, "//CRISIdentifier");
        }
        public static void SwapCrisCRP(string CIFID, string criscode, out string statuscode, out string response)
        {
            var _url = "https://nd.t5.ep.test.cba:9944/RiskProfileManagement/V1/PS00";
            var _action = "http://ep.cba/core/services/enterprise/riskmanagement/riskprofilemanagement/v1/swapRiskData";
            var _path = Path.GetFullPath(@"./data/soap_services/riskprofilemanagement.xml");


            XmlDocument soapEnvelopeXml = ConstructRequest.UpdateSingleField(_path, "CIFIdentifier", CIFID);
            soapEnvelopeXml = ConstructRequest.UpdateSingleField(soapEnvelopeXml, "CRISIdentifier", criscode);
            CommBank.Testing.WebServices.Core.WebService.Post(_url, _action, soapEnvelopeXml, out statuscode, out response);

        }

        public string GetXmlElement(string xml, string expression, int occurence = 0)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            XmlNodeList nodes = doc.GetElementsByTagName(expression);

            return nodes[occurence].InnerText;

        }
    }
}
