# IBB.WebService.DataCreation
Tool for customer Origination and Risk profile creation
