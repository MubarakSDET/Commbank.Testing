﻿using System;
using System.IO;
using System.Linq;

namespace CommBank.Testing.WebServices.Utilities
{
    public class DataSheet
    {
        string[] seps = { "\",", ",\"", "," };
        char[] quotes = { '\"', ' ' };
        string[] colFields = null;
        public string Path { get; set; }
        public int RowCount {
            get { return GetRows().Count();  }  }
        public int ColumnCount
        {
            get { return GetHeader().Count(); }
        }
        public string[] GetRows()
        {
            return File.ReadAllLines(Path);
        }
        public string[] GetRowByIndex(int Index)
        {
            return GetRows().ElementAt(Index).Split(seps, StringSplitOptions.None);
            //.Select(s => s.Trim(quotes).Replace("\\\"", "\""))
            //.ToArray();
        }
        public string[] GetHeader()
        {
            return GetRows().ElementAt(0).Split(seps, StringSplitOptions.None);

        }
        public string GetColumnValue(string ColumnName, int rowIndex)
        {
            var ColumnIndex = GetHeader().ToList().IndexOf(ColumnName);
            return GetRowByIndex(rowIndex).ElementAt(ColumnIndex).ToString();
        }
        public void SetColumnValue(string ColumnName, int rowIndex, string value)
        {
            var ColumnIndex = GetHeader().ToList().IndexOf(ColumnName);
            var AllLines = File.ReadAllLines(Path);
            // Creates Column If dosen't exists'
            if (ColumnIndex == -1)
            {
                AllLines[0] = AllLines[0] + "," + ColumnName;
                int i = -1;
                AllLines.ToList().ForEach(x => { i++; if (i > 0) { AllLines[i] = AllLines[i] + ","; } });
                File.WriteAllLines(Path, AllLines);
                AllLines = File.ReadAllLines(Path);
                ColumnIndex = GetHeader().ToList().IndexOf(ColumnName);
            }

            var SelectedLine = AllLines[rowIndex].Split(',').ToList();
            SelectedLine[ColumnIndex] = value;
            AllLines[rowIndex] = String.Join(",", SelectedLine.ToArray());
            File.WriteAllLines(Path, AllLines);
        }
    }
}
