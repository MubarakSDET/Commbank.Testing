﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;

namespace CommBank.Testing.WebServices.Data
{
    public static class ConstructRequest
    {
        public static XmlDocument Reconstruct(XmlDocument dom,  string TagName , string value)
        {
            XmlNodeList node = dom.GetElementsByTagName(TagName);
            if (TagName.StartsWith("/"))
            {
                node = dom.SelectNodes(TagName);
            }
            if (node.Count > 0)
                node[0].InnerText = value;
            return dom;
        }

        public static XmlDocument DomObject(string Path)
        {
            XmlDocument dom = new XmlDocument();
            dom.Load(Path);
            return dom;
        }
        public static XmlDocument UpdateAllField(String Path, string[] key,string[] value)
        {
            XmlDocument wsRequest = DomObject(Path);
            for(int k=0; k<key.Length;k++)
            {
                Reconstruct(wsRequest, key.ElementAt(k), value.ElementAt(k));
            }
            return wsRequest;
        }
        public static XmlDocument UpdateSingleField(String Path, string key, string value)
        {
            XmlDocument wsRequest = DomObject(Path);
            Reconstruct(wsRequest, key, value);
            return wsRequest;
        }
        public static XmlDocument UpdateSingleField(XmlDocument wsRequest, string key, string value)
        {
            Reconstruct(wsRequest, key, value);
            return wsRequest;
        }
        public static string[] GetData(XmlDocument dom, string TagName)
        {
            XmlNodeList node = dom.GetElementsByTagName(TagName);
            List<string> data = new List<string>();
            foreach (XmlNode n in node)
            {
                data.Add(n.InnerText);
            }
            return data.ToArray();
        }
        public static string[] GetData(string xml, string TagName)
        {
            XmlDocument dom = new XmlDocument();
            dom.LoadXml(xml);
            return GetData(dom, TagName);
        }

        public static string GetDataxpath(string xml, string expression)
        {
            XmlDocument dom = new XmlDocument();
            dom.LoadXml(xml);
            var root = dom.GetElementsByTagName("soap:Body");
            if(root.Count == 0)
                root = dom.GetElementsByTagName("soapenv:Body");
            XDocument response = XDocument.Parse(root[0].InnerXml);
            var node = response.XPathSelectElements(expression);
            return node.ElementAt(0).Value.ToString();
            //return null;
             
        }

        public static XmlDocument SetDataxpath(string xml, string expression, string value )
        {

            XmlDocument dom = new XmlDocument();
            dom.LoadXml(xml);
            var root = dom.GetElementsByTagName("soap:Body");
            var node = root[0].SelectSingleNode(expression);
            node.Value = value;
            return dom;
        }

        private static XmlDocument ToXmlDocument(XDocument xDocument)
        {
            var xmlDocument = new XmlDocument();
            using (var xmlReader = xDocument.CreateReader())
            {
                xmlDocument.Load(xmlReader);
            }
            return xmlDocument;
        }
    }
}
