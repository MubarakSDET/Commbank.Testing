﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using CommBank.Testing.Cryptography;

namespace CommBank.Testing.WebServices.Core
{
    class WebService
    {
        
        public static void Post(string _url, string _action, XmlDocument soapEnvelopeXml, out string statuscode, out string response)
        {
            HttpWebRequest webRequest;
            if (_action.ToLower().Contains("ep.cba"))
            {
                webRequest = EPCreateWebRequest(_url, _action);
            }
            else
            webRequest = CreateWebRequest(_url, _action);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3|SecurityProtocolType.Tls;
            ServicePointManager.ServerCertificateValidationCallback +=
                (sender, cert, chain, sslPolicyErrors) => { return true; };
            InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXml, webRequest);

            // begin async call to web request.
            IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);

            // suspend this thread until call is complete. You might want to
            // do something usefull here like update your UI.
            asyncResult.AsyncWaitHandle.WaitOne();

            // get the response from the completed web request.
            string soapResult;
            using (WebResponse webResponse = webRequest.EndGetResponse(asyncResult))
            {
                statuscode = ((HttpWebResponse)webResponse).StatusCode.ToString();
                using (StreamReader rd = new StreamReader(webResponse.GetResponseStream()))
                {
                    soapResult = rd.ReadToEnd();
                }
                response = soapResult;
            }
        }

        private static HttpWebRequest CreateWebRequest(string url, string action)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            string credentials = String.Format("{0}:{1}", ConfigurationManager.AppSettings.Get("IFW.Username"), new Crypto().Decrypt(ConfigurationManager.AppSettings.Get("IFW.Password")));
            //string credentials = String.Format("{0}:{1}", "brancht01\\ifwsystem", "Password01");
            byte[] bytes = Encoding.ASCII.GetBytes(credentials);
            string base64 = Convert.ToBase64String(bytes);
            string authorization = String.Concat("Basic ", base64);
            webRequest.Headers.Add("Authorization", authorization);
            webRequest.Headers.Add("SOAPAction", action);
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "text/xml";
            webRequest.Method = "POST";
            return webRequest;
        }

        private static HttpWebRequest EPCreateWebRequest(string url, string action)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            string credentials = String.Format("{0}:{1}", ConfigurationManager.AppSettings.Get("IFW.Username"), new Crypto().Decrypt(ConfigurationManager.AppSettings.Get("IFW.Password")));
            //string credentials = String.Format("{0}:{1}", "brancht01\\ifwsystem", "Password01");
            byte[] bytes = Encoding.ASCII.GetBytes(credentials);
            string base64 = Convert.ToBase64String(bytes);
            string authorization = "Basic RVAtRG9tYWluXEFDT0VfQ0VfRVBfVDE6UGFzc3dvcmQwMQ=="; // String.Concat("Basic ", base64);
            webRequest.Headers.Add("Authorization", authorization);
            webRequest.Headers.Add("SOAPAction", action);
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "gzip, deflate";
            webRequest.Method = "POST";
            return webRequest;
        }
        private static XmlDocument CreateSoapEnvelope()
        {
            XmlDocument soapEnvelopeDocument = new XmlDocument();
            soapEnvelopeDocument.LoadXml(@"<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/1999/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/1999/XMLSchema""><SOAP-ENV:Body><HelloWorld xmlns=""http://tempuri.org/"" SOAP-ENV:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding/""><int1 xsi:type=""xsd:integer"">12</int1><int2 xsi:type=""xsd:integer"">32</int2></HelloWorld></SOAP-ENV:Body></SOAP-ENV:Envelope>");
            return soapEnvelopeDocument;
        }

        private static void InsertSoapEnvelopeIntoWebRequest(XmlDocument soapEnvelopeXml, HttpWebRequest webRequest)
        {
            using (Stream stream = webRequest.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }
        }

        
    }
}
