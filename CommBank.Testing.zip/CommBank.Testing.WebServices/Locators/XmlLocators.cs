﻿namespace CommBank.Testing.WebServices.Locators
{
    public class CustomerDetails
    {
        public const string FirstName = "firstName";
        public const string LastName = "lastName";
        public const string MiddleName = "middleNames";
        public const string DateOfBirth = "birthDate";
        public const string Gender = "gender";
        public const string CustomerStatus = "personalStatus";
        public const string Title = "prefixTitle";

    }
   
    public class CustomerSearchResults
    {
        public const string CustomerID = "CIFIdentifier";
        public const string AddressLine1 = "line1";
        public const string AddressLine2 = "line2";
        public const string Suburb = "suburb";
        public const string FullName = "customerName";
        public const string DateOfBirth = "birthDate";
        public const string State = "state";
        public const string PostCode = "postcode";
    }
}