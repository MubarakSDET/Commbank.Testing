﻿using NUnit.Framework;

namespace ComplexProducts.Testing.NUnit3
{
    public static class NUnitExtensions
    {
        public static bool HasPassed(this TestContext.ResultAdapter results) => results.PassCount > 0;
    }
}