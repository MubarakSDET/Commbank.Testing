﻿using System;
using Allure.Commons;
using CommBank.Testing.Extensions;
using NUnit.Allure.Core;
using NUnit.Framework;

namespace CommBank.Testing.Allure
{
    public class AllureReportsGenerationSetupFixture
    {
        [OneTimeSetUp]
        public void CleanupResultDirectory()
        {
            Environment.CurrentDirectory = GetType().Assembly.GetLocation();

            AllureExtensions.WrapSetUpTearDownParams(() => { AllureLifecycle.Instance.CleanupResultDirectory(); },
                "Cleanup Allure Results Directory");
        }

        [OneTimeTearDown]
        public void TestDown() => AllureHelper.GenerateReport(GetType().Assembly.GetReportsFolder());
    }
}