﻿using System.Diagnostics;
using System.IO;
using System.Reflection;
using Allure.Commons;
using CommBank.Testing.Extensions;
using System;
using System.Collections.Generic;

namespace CommBank.Testing.Allure
{
    public static class AllureHelper
    {
        private static readonly AllureLifecycle allure = AllureLifecycle.Instance;

        public static void GenerateReport(string reportsDirectory)
        {
            var allureResultsDirectory = AllureLifecycle.Instance.ResultsDirectory;
            var allureResultsDirectoryInfo = new DirectoryInfo(allureResultsDirectory);
            var allureResultsHistoryDirectory = Path.Combine(reportsDirectory, "history");
            var allureResultsHistoryDirectoryInfo = new DirectoryInfo(allureResultsHistoryDirectory);

            if (allureResultsDirectoryInfo.Exists && allureResultsHistoryDirectoryInfo.Exists)
            {
                var sourceHistoryPath = $@"{allureResultsHistoryDirectory}";
                var destDirectoryPath = new DirectoryInfo($@"{Path.Combine(allureResultsDirectory, "history")}");

                if (destDirectoryPath.Exists) destDirectoryPath.Delete(true);

                DirectoryCopy(sourceHistoryPath, destDirectoryPath.FullName, true);
            }

            var allurePath = Assembly.GetExecutingAssembly().GetAllurePath();
            //var _allureScript = allurePath + "\\" + $@"allure generate --clean {allureResultsDirectory} -o {reportsDirectory}";
            var allureScript = "\"\"" + allurePath + "\\" + $@"allure"" generate --clean ""{allureResultsDirectory}"" -o ""{reportsDirectory}""" + "\"";
            var process = new Process();
            var startInfo = new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Hidden,
                FileName = "cmd.exe",
                Arguments = $"/C {allureScript}"
            };
            process.StartInfo = startInfo;
            process.Start();
            process.WaitForExit();
        }

        private static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            var dir = new DirectoryInfo(sourceDirName);

            if (!dir.Exists) throw new DirectoryNotFoundException($"Source directory does not exist or could not be found: {sourceDirName}");

            Directory.CreateDirectory(destDirName);

            var files = dir.GetFiles();
            foreach (var file in files) file.CopyTo(Path.Combine(destDirName, file.Name), false);

            if (!copySubDirs) return;

            var dirs = dir.GetDirectories();
            foreach (var subDir in dirs) DirectoryCopy(subDir.FullName, Path.Combine(destDirName, subDir.Name), copySubDirs);
        }


        public static void ReportEvent(string stepName, string Description, Status result)
        {
            
            var id = Guid.NewGuid().ToString();
            var stepResult = new StepResult { name = stepName };
            var parameters = new List<Parameter>();
            parameters.Add(new Parameter { name = stepName, value = Description });
            stepResult.parameters = parameters;

            try
            {
                allure.StartStep(id, stepResult);
                allure.StopStep(step => stepResult.status = result);
            }
            catch (Exception e)
            {
                allure.StopStep(step =>
                {
                    step.statusDetails = new StatusDetails
                    {
                        message = e.Message,
                        trace = e.StackTrace
                    };
                    step.status = Status.none;
                });
                throw;
            }

        }
    }
}