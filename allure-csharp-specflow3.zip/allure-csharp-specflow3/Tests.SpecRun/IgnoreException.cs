﻿using System;

namespace Tests.SpecRun
{
    class IgnoreException : Exception
    {
    }
}
